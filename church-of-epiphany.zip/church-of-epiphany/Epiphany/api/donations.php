<?php
require_once '../db.php';

$limit = '';
if (isset($_GET['limit'])) {
    $limit = "LIMIT " . intval($_GET['limit']);
}

$result = $conn->query("SELECT * FROM donations ORDER BY donation_date DESC $limit");
$donations = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $donations[] = $row;
    }
}

echo json_encode(['success' => true, 'data' => $donations]);
$conn->close();
?>