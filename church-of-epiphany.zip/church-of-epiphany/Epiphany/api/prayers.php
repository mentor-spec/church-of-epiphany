<?php
require_once '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get specific prayer request by ID
    if (isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $stmt = $conn->prepare("SELECT * FROM prayer_requests WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            echo json_encode(['success' => true, 'data' => $result->fetch_assoc()]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Prayer request not found']);
        }
        $stmt->close();
    } else {
        // Get all prayer requests
        $result = $conn->query("SELECT * FROM prayer_requests ORDER BY created_at DESC");
        $prayers = [];
        
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $prayers[] = $row;
            }
        }
        
        echo json_encode(['success' => true, 'data' => $prayers]);
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    // Update prayer request status
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (isset($input['mark_all_read'])) {
        // Mark all as read
        $conn->query("UPDATE prayer_requests SET status = 'read' WHERE status = 'new'");
        echo json_encode(['success' => true, 'message' => 'All prayers marked as read']);
        
    } elseif (isset($input['id']) && isset($input['status'])) {
        // Update specific prayer
        $id = intval($input['id']);
        $status = $conn->real_escape_string($input['status']);
        
        $stmt = $conn->prepare("UPDATE prayer_requests SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $id);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Prayer updated successfully']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Update failed']);
        }
        $stmt->close();
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // Delete read prayers
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (isset($input['delete_read'])) {
        $conn->query("DELETE FROM prayer_requests WHERE status = 'read' OR status = 'prayed'");
        echo json_encode(['success' => true, 'message' => 'Read prayers deleted successfully']);
    }
}

$conn->close();
?>