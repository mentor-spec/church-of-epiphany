<?php
require_once '../db.php';

$result = $conn->query("SELECT * FROM users ORDER BY created_at DESC");
$users = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}

echo json_encode(['success' => true, 'data' => $users]);
$conn->close();
?>