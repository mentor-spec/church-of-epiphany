<?php
require_once '../db.php';

// Simple file upload simulation
// In production, you would handle actual file uploads
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = isset($_POST['title']) ? $conn->real_escape_string($_POST['title']) : 'New Sermon';
    $speaker = isset($_POST['speaker']) ? $conn->real_escape_string($_POST['speaker']) : 'Unknown Speaker';
    
    $sql = "INSERT INTO sermons (title, speaker, sermon_date) VALUES ('$title', '$speaker', CURDATE())";
    
    if ($conn->query($sql)) {
        echo json_encode(['success' => true, 'message' => 'Sermon uploaded successfully']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Upload failed: ' . $conn->error]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}

$conn->close();
?>