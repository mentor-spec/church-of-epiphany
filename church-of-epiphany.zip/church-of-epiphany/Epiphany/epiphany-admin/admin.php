<?php
// admin_dashboard.php

require_once 'db.php';

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    /** -----------------------------
     *  ADD ANNOUNCEMENT
     * ----------------------------- */
    if (isset($_POST['add_announcement'])) {
        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $category = mysqli_real_escape_string($conn, $_POST['category']);
        $content = mysqli_real_escape_string($conn, $_POST['content']);
        $publish_date = mysqli_real_escape_string($conn, $_POST['publish_date']);
        $status = mysqli_real_escape_string($conn, $_POST['status']);
        
        $sql = "INSERT INTO announcements (title, category, content, publish_date, status, created_at) 
                VALUES ('$title', '$category', '$content', '$publish_date', '$status', NOW())";
        
        $_SESSION['success_message'] = mysqli_query($conn, $sql)
            ? "Announcement added successfully!"
            : "Error adding announcement: " . mysqli_error($conn);
    }

    /** -----------------------------
     *  ADD SERMON
     * ----------------------------- */
    if (isset($_POST['add_sermon'])) {
        $title = mysqli_real_escape_string($conn, $_POST['sermon_title']);
        $speaker = mysqli_real_escape_string($conn, $_POST['sermon_speaker']);
        $description = mysqli_real_escape_string($conn, $_POST['sermon_description']);
        $video_url = mysqli_real_escape_string($conn, $_POST['sermon_video_url']);
        $audio_url = mysqli_real_escape_string($conn, $_POST['sermon_audio_url']);
        $sermon_date = mysqli_real_escape_string($conn, $_POST['sermon_date']);
        
        $sql = "INSERT INTO sermons (title, speaker, description, video_url, audio_url, sermon_date)
                VALUES ('$title', '$speaker', '$description', '$video_url', '$audio_url', '$sermon_date')";
        
        $_SESSION['success_message'] = mysqli_query($conn, $sql)
            ? "Sermon added successfully!"
            : "Error adding sermon: " . mysqli_error($conn);
    }

    /** -----------------------------
     *  ADD GALLERY IMAGE
     * ----------------------------- */
    if (isset($_POST['add_gallery_image'])) {
        $title = mysqli_real_escape_string($conn, $_POST['image_title']);
        $description = mysqli_real_escape_string($conn, $_POST['image_description']);
        $category = mysqli_real_escape_string($conn, $_POST['image_category']);

        if (isset($_FILES['image_file']) && $_FILES['image_file']['error'] === 0) {
            $base_dir = __DIR__;
            $upload_dir = $base_dir . "/uploads/gallery/";

            // Ensure upload directory exists
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

            // Clean file name and define path
            $original_name = basename($_FILES['image_file']['name']);
            $clean_name = preg_replace('/[^\w\.-]/', '_', $original_name);
            $file_name = time() . '_' . $clean_name;
            $target_file = $upload_dir . $file_name;

            // ✅ Store only short relative path (no "epiphany-admin" prefix)
            $db_path = "uploads/gallery/" . $file_name;

            if (move_uploaded_file($_FILES['image_file']['tmp_name'], $target_file)) {
                $sql = "INSERT INTO gallery (title, description, category, image_path) 
                        VALUES ('$title', '$description', '$category', '$db_path')";
                if (mysqli_query($conn, $sql)) {
                    $_SESSION['success_message'] = "Image uploaded successfully!";
                } else {
                    $_SESSION['error_message'] = "Database insert failed: " . mysqli_error($conn);
                    unlink($target_file);
                }
            } else {
                $_SESSION['error_message'] = "Failed to upload image file.";
            }
        } else {
            $_SESSION['error_message'] = "No valid image file selected.";
        }
    }

    /** -----------------------------
     *  ADD USER
     * ----------------------------- */
    if (isset($_POST['add_user'])) {
        $name = mysqli_real_escape_string($conn, $_POST['user_name']);
        $email = mysqli_real_escape_string($conn, $_POST['user_email']);
        $role = mysqli_real_escape_string($conn, $_POST['user_role']);
        $password = password_hash($_POST['user_password'], PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO users (name, email, password, role)
                VALUES ('$name', '$email', '$password', '$role')";
        
        $_SESSION['success_message'] = mysqli_query($conn, $sql)
            ? "User added successfully!"
            : "Error adding user: " . mysqli_error($conn);
    }

    /** -----------------------------
     *  ADD/UPDATE LIVESTREAM
     * ----------------------------- */
    if (isset($_POST['add_livestream'])) {
        $title = mysqli_real_escape_string($conn, $_POST['stream_title']);
        $stream_url = mysqli_real_escape_string($conn, $_POST['stream_url']);
        $stream_key = mysqli_real_escape_string($conn, $_POST['stream_key']);
        $description = mysqli_real_escape_string($conn, $_POST['stream_description']);
        $scheduled_time = mysqli_real_escape_string($conn, $_POST['scheduled_time']);
        $is_live = isset($_POST['is_live']) ? 1 : 0;
        
        // Debug: Check what values we're receiving
        error_log("Livestream Data: Title=$title, URL=$stream_url, Scheduled=$scheduled_time, Live=$is_live");
        
        // Validate required fields
        if (empty($title) || empty($stream_url)) {
            $_SESSION['error_message'] = "Title and Stream URL are required fields.";
        } else {
            // Handle empty scheduled_time
            if (empty($scheduled_time)) {
                $sql = "INSERT INTO livestreams (title, stream_url, stream_key, description, is_live) 
                        VALUES ('$title', '$stream_url', '$stream_key', '$description', '$is_live')";
            } else {
                $sql = "INSERT INTO livestreams (title, stream_url, stream_key, description, scheduled_time, is_live) 
                        VALUES ('$title', '$stream_url', '$stream_key', '$description', '$scheduled_time', '$is_live')";
            }
            
            error_log("SQL Query: " . $sql); // Debug the SQL
            
            if (mysqli_query($conn, $sql)) {
                $_SESSION['success_message'] = "Live stream added successfully!";
            } else {
                $error_msg = "Error adding live stream: " . mysqli_error($conn);
                $_SESSION['error_message'] = $error_msg;
                error_log($error_msg); // Log the error
            }
        }
    }

    if (isset($_POST['update_livestream_status'])) {
        $stream_id = mysqli_real_escape_string($conn, $_POST['stream_id']);
        $is_live = mysqli_real_escape_string($conn, $_POST['is_live']);
        
        $sql = "UPDATE livestreams SET is_live='$is_live', updated_at=NOW() WHERE id='$stream_id'";
        
        $_SESSION['success_message'] = mysqli_query($conn, $sql)
            ? "Live stream status updated!"
            : "Error updating stream: " . mysqli_error($conn);
    }

    /** -----------------------------
     *  UPDATE SETTINGS
     * ----------------------------- */
    if (isset($_POST['update_settings'])) {
        $_SESSION['success_message'] = "Settings updated successfully!";
    }

    header("Location: admin.php");
    exit;
}

/** -----------------------------
 *  HANDLE GET ACTIONS
 * ----------------------------- */
if (isset($_GET['action'])) {
    $id = isset($_GET['id']) ? mysqli_real_escape_string($conn, $_GET['id']) : null;

    switch ($_GET['action']) {
        case 'delete_announcement':
            mysqli_query($conn, "DELETE FROM announcements WHERE id='$id'");
            $_SESSION['success_message'] = "Announcement deleted.";
            break;

        case 'toggle_announcement':
            mysqli_query($conn, "UPDATE announcements 
                                 SET status = CASE WHEN status='active' THEN 'inactive' ELSE 'active' END
                                 WHERE id='$id'");
            break;

        case 'delete_sermon':
            mysqli_query($conn, "DELETE FROM sermons WHERE id='$id'");
            $_SESSION['success_message'] = "Sermon deleted.";
            break;

        case 'delete_gallery_image':
            $res = mysqli_query($conn, "SELECT image_path FROM gallery WHERE id='$id'");
            if ($res && $row = mysqli_fetch_assoc($res)) {
                $image_path = __DIR__ . '/' . $row['image_path'];
                if (file_exists($image_path)) unlink($image_path);
            }
            mysqli_query($conn, "DELETE FROM gallery WHERE id='$id'");
            $_SESSION['success_message'] = "Image deleted.";
            break;

        case 'mark_prayed':
            mysqli_query($conn, "UPDATE prayer_requests SET status='prayed', prayed_at=NOW() WHERE id='$id'");
            break;

        case 'delete_prayer':
            mysqli_query($conn, "DELETE FROM prayer_requests WHERE id='$id'");
            break;

        case 'delete_user':
            mysqli_query($conn, "DELETE FROM users WHERE id='$id'");
            $_SESSION['success_message'] = "User deleted.";
            break;

        case 'delete_livestream':
            mysqli_query($conn, "DELETE FROM livestreams WHERE id='$id'");
            $_SESSION['success_message'] = "Live stream deleted.";
            break;
    }

    header("Location: admin.php");
    exit;
}

/** -----------------------------
 *  FETCH DASHBOARD DATA
 * ----------------------------- */
function fetch_all_assoc($conn, $sql) {
    $res = mysqli_query($conn, $sql);
    return $res ? mysqli_fetch_all($res, MYSQLI_ASSOC) : [];
}

$announcements = fetch_all_assoc($conn, "SELECT * FROM announcements ORDER BY created_at DESC");
$prayer_requests = fetch_all_assoc($conn, "SELECT * FROM prayer_requests ORDER BY submitted_at DESC");
$sermons = fetch_all_assoc($conn, "SELECT * FROM sermons ORDER BY sermon_date DESC");
$gallery_images = fetch_all_assoc($conn, "SELECT * FROM gallery ORDER BY created_at DESC");
$donations = fetch_all_assoc($conn, "SELECT * FROM donations ORDER BY donation_date DESC LIMIT 10");
$users = fetch_all_assoc($conn, "SELECT * FROM users ORDER BY created_at DESC");

// Add livestream data
$livestreams = fetch_all_assoc($conn, "SELECT * FROM livestreams ORDER BY scheduled_time DESC");
$active_livestream = fetch_all_assoc($conn, "SELECT * FROM livestreams WHERE is_live=1 LIMIT 1");

// Stats
$stats = [
    'sermons' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM sermons"))['count'],
    'announcements' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM announcements"))['count'],
    'prayers' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM prayer_requests"))['count'],
    'users' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM users"))['count'],
    'gallery' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM gallery"))['count'],
    'donations' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM donations"))['count'],
    'livestreams' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM livestreams"))['count']
];

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Epiphany — Admin Dashboard</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.3.0/dist/chart.umd.min.js"></script>

  <style>
    :root {
      --sidebar: #343a40;
      --accent: #6c63ff;
      --bg-light: #f4f6f9;
      --transition: all 0.3s ease;
    }

    body {
      font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      background: var(--bg-light);
      margin: 0;
      padding: 0;
      overflow-x: hidden;
      transition: var(--transition);
    }

    /* ---------------- SIDEBAR ---------------- */
    .sidebar {
      width: 260px;
      position: fixed;
      height: 100vh;
      left: 0;
      top: 0;
      background: var(--sidebar);
      color: #fff;
      padding: 22px 14px;
      overflow-y: auto;
      transition: var(--transition);
      z-index: 1000;
      box-shadow: 2px 0 10px rgba(0,0,0,0.1);
    }

    .sidebar.collapsed {
      width: 70px;
    }

    .sidebar.collapsed .nav-link span,
    .sidebar.collapsed .sidebar-brand-text,
    .sidebar.collapsed .sidebar-footer-text {
      display: none;
    }

    .sidebar.collapsed .nav-link {
      justify-content: center;
      padding: 10px;
    }

    .sidebar.collapsed .nav-link i {
      margin-right: 0;
    }

    .sidebar .nav-link {
      color: #e9ecef;
      border-radius: 8px;
      padding: 10px 12px;
      display: flex;
      align-items: center;
      font-size: 0.95rem;
      transition: var(--transition);
      white-space: nowrap;
    }

    .sidebar .nav-link i {
      min-width: 20px;
      text-align: center;
      margin-right: 10px;
      transition: var(--transition);
    }

    .sidebar .nav-link:hover,
    .sidebar .nav-link.active {
      background: rgba(255, 255, 255, 0.08);
      color: #fff;
    }

    .sidebar .profile-img {
      width: 42px;
      height: 42px;
      border-radius: 50%;
      object-fit: cover;
    }

    .sidebar-footer {
      position: sticky;
      bottom: 12px;
      background: var(--sidebar);
      padding-top: 10px;
    }

    /* ---------------- CONTENT AREA ---------------- */
    .content {
      margin-left: 260px;
      padding: 28px;
      transition: var(--transition);
    }

    .content.expanded {
      margin-left: 70px;
    }

    /* Cards */
    .card-stats {
      border-radius: 12px;
      padding: 20px;
      background: #fff;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
      transition: var(--transition);
      text-align: center;
    }

    .card-stats:hover {
      transform: translateY(-3px);
      box-shadow: 0 8px 15px rgba(0,0,0,0.1);
    }

    /* Status badges */
    .badge-active { background: #10b981; }
    .badge-inactive { background: #6b7280; }
    .badge-draft { background: #f59e0b; }
    .badge-pending { background: #ef4444; }
    .badge-completed { background: #10b981; }
    .badge-failed { background: #ef4444; }

    /* Table actions */
    .table-actions {
      display: flex;
      gap: 5px;
    }

    .btn-table {
      padding: 4px 8px;
      font-size: 0.75rem;
    }

    /* Gallery images */
    .gallery-img {
      height: 200px;
      object-fit: cover;
      transition: var(--transition);
    }

    .gallery-card:hover .gallery-img {
      transform: scale(1.05);
    }

    /* Live stream preview */
    .live-preview {
      background: linear-gradient(45deg, #1a1a1a, #2d2d2d);
      border-radius: 8px;
      padding: 20px;
      color: white;
    }

    /* Responsive */
    @media (max-width: 991px) {
      .sidebar {
        left: -280px;
      }

      .sidebar.mobile-open {
        left: 0;
      }

      .content {
        margin-left: 0;
      }

      .mobile-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        z-index: 999;
      }

      .mobile-overlay.active {
        display: block;
      }
    }
  </style>
</head>
<body>

  <!-- Mobile Overlay -->
  <div class="mobile-overlay" id="mobileOverlay"></div>

  <!-- NOTIFICATION TOAST -->
  <?php if (isset($_SESSION['success_message'])): ?>
  <div class="position-fixed top-0 end-0 p-3" style="z-index: 1100">
    <div class="toast show" role="alert">
      <div class="toast-header bg-success text-white">
        <strong class="me-auto">Success</strong>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
      </div>
      <div class="toast-body">
        <?= $_SESSION['success_message'] ?>
      </div>
    </div>
  </div>
  <?php unset($_SESSION['success_message']); endif; ?>

  <?php if (isset($_SESSION['error_message'])): ?>
  <div class="position-fixed top-0 end-0 p-3" style="z-index: 1100">
    <div class="toast show" role="alert">
      <div class="toast-header bg-danger text-white">
        <strong class="me-auto">Error</strong>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
      </div>
      <div class="toast-body">
        <?= $_SESSION['error_message'] ?>
      </div>
    </div>
  </div>
  <?php unset($_SESSION['error_message']); endif; ?>

  <!-- SIDEBAR -->
  <aside class="sidebar" id="sidebar">
    <div class="d-flex align-items-center mb-3">
      <img src="./church.jpg" alt="logo" class="profile-img me-2">
      <div class="sidebar-brand-text">
        <strong>Epiphany Admin</strong>
        <div class="small text-muted">Administrator</div>
      </div>
    </div>

    <nav class="nav flex-column mb-3">
      <a class="nav-link active" href="#" data-section="dashboard"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
      <a class="nav-link" href="#" data-section="sermons"><i class="fas fa-video"></i><span>Manage Sermons</span></a>
      <a class="nav-link" href="#" data-section="announcements"><i class="fas fa-bullhorn"></i><span>Announcements</span></a>
      <a class="nav-link" href="#" data-section="livestream"><i class="fas fa-broadcast-tower"></i><span>Live Stream</span></a>
      <a class="nav-link" href="#" data-section="prayers"><i class="fas fa-praying-hands"></i><span>Prayer Requests</span></a>
      <a class="nav-link" href="#" data-section="gallery"><i class="fas fa-images"></i><span>Gallery</span></a>
      <a class="nav-link" href="#" data-section="payments"><i class="fas fa-hand-holding-dollar"></i><span>Donations</span></a>
      <a class="nav-link" href="#" data-section="users"><i class="fas fa-users"></i><span>Users</span></a>
      <a class="nav-link" href="#" data-section="settings"><i class="fas fa-cogs"></i><span>Settings</span></a>
      <a class="nav-link text-danger mt-2" href="logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </nav>

    <div class="sidebar-footer">
      <div class="sidebar-footer-text small text-muted mb-2">Quick actions</div>
      <button class="btn btn-sm btn-light w-100 mb-2" data-bs-toggle="modal" data-bs-target="#announcementModal">
        <i class="fas fa-plus me-2"></i><span>New Announcement</span>
      </button>
      <button class="btn btn-sm btn-outline-light w-100" id="sidebarToggle">
        <i class="fas fa-chevron-left"></i><span>Collapse</span>
      </button>
    </div>
  </aside>

  <!-- MAIN CONTENT -->
  <main class="content" id="mainContent">
    <!-- TOP BAR -->
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div class="d-flex align-items-center gap-3">
        <button class="btn btn-outline-secondary d-lg-none" id="mobileMenuToggle">
          <i class="fas fa-bars"></i>
        </button>
        <h4 class="mb-0" id="sectionTitle">Dashboard</h4>
        <small class="text-muted" id="sectionDescription">Welcome back — here is a snapshot of activity</small>
      </div>

      <div class="d-flex align-items-center gap-3">
        <div class="position-relative me-2">
          <input class="form-control form-control-sm ps-4" id="searchBox" placeholder="Search...">
          <i class="fas fa-search position-absolute top-50 translate-middle-y ms-2 text-muted"></i>
        </div>
        <button class="btn btn-outline-secondary btn-sm" id="btnExportCSV">
          <i class="fas fa-file-csv me-1"></i>Export CSV
        </button>
      </div>
    </div>

    <!-- DASHBOARD SECTION -->
    <section id="dashboardSection">
      <div class="row g-3 mb-4">
        <div class="col-md-3">
          <div class="card-stats text-center">
            <i class="fas fa-video fa-2x mb-2" style="color:var(--accent)"></i>
            <div class="small text-muted">Total Sermons</div>
            <h3><?= $stats['sermons'] ?></h3>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card-stats text-center">
            <i class="fas fa-bullhorn fa-2x mb-2" style="color:#10b981"></i>
            <div class="small text-muted">Announcements</div>
            <h3><?= $stats['announcements'] ?></h3>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card-stats text-center">
            <i class="fas fa-praying-hands fa-2x mb-2" style="color:#f59e0b"></i>
            <div class="small text-muted">Prayer Requests</div>
            <h3><?= $stats['prayers'] ?></h3>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card-stats text-center">
            <i class="fas fa-users fa-2x mb-2" style="color:#ef4444"></i>
            <div class="small text-muted">Members</div>
            <h3><?= $stats['users'] ?></h3>
          </div>
        </div>
      </div>

      <div class="row g-3">
        <div class="col-md-3">
          <div class="card-stats text-center">
            <i class="fas fa-images fa-2x mb-2" style="color:#8b5cf6"></i>
            <div class="small text-muted">Gallery Images</div>
            <h3><?= $stats['gallery'] ?></h3>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card-stats text-center">
            <i class="fas fa-donate fa-2x mb-2" style="color:#06b6d4"></i>
            <div class="small text-muted">Total Donations</div>
            <h3><?= $stats['donations'] ?></h3>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card-stats text-center">
            <i class="fas fa-broadcast-tower fa-2x mb-2" style="color:#ff6b6b"></i>
            <div class="small text-muted">Live Streams</div>
            <h3><?= $stats['livestreams'] ?></h3>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card p-3">
            <h6>Recent Activity</h6>
            <div class="mt-2">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="small">New prayer requests</span>
                <span class="badge bg-primary"><?= $stats['prayers'] ?></span>
              </div>
              <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="small">Active announcements</span>
                <span class="badge bg-success"><?= $stats['announcements'] ?></span>
              </div>
              <div class="d-flex justify-content-between align-items-center">
                <span class="small">Total members</span>
                <span class="badge bg-info"><?= $stats['users'] ?></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ANNOUNCEMENTS SECTION -->
    <section id="announcementsSection" class="d-none">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5>Manage Announcements</h5>
        <div>
          <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#announcementModal">
            <i class="fas fa-plus me-1"></i>New Announcement
          </button>
        </div>
      </div>

      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Category</th>
                  <th>Publish Date</th>
                  <th>Status</th>
                  <th>Created</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($announcements)): ?>
                  <tr>
                    <td colspan="6" class="text-center py-4 text-muted">
                      No announcements found. <a href="#" data-bs-toggle="modal" data-bs-target="#announcementModal">Create your first announcement</a>
                    </td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($announcements as $announcement): ?>
                  <tr>
                    <td>
                      <strong><?= htmlspecialchars($announcement['title']) ?></strong>
                      <?php if (strlen($announcement['content']) > 100): ?>
                        <br><small class="text-muted"><?= substr(htmlspecialchars($announcement['content']), 0, 100) ?>...</small>
                      <?php endif; ?>
                    </td>
                    <td>
                      <span class="badge bg-secondary"><?= htmlspecialchars($announcement['category']) ?></span>
                    </td>
                    <td><?= date('M j, Y', strtotime($announcement['publish_date'])) ?></td>
                    <td>
                      <span class="badge badge-<?= $announcement['status'] ?>">
                        <?= ucfirst($announcement['status']) ?>
                      </span>
                    </td>
                    <td><?= date('M j, Y', strtotime($announcement['created_at'])) ?></td>
                    <td>
                      <div class="table-actions">
                        <button class="btn btn-sm btn-outline-primary" 
                                onclick="editAnnouncement(<?= $announcement['id'] ?>)"
                                data-bs-toggle="tooltip" title="Edit">
                          <i class="fas fa-edit"></i>
                        </button>
                        <a href="?action=toggle_announcement&id=<?= $announcement['id'] ?>" 
                           class="btn btn-sm btn-outline-<?= $announcement['status'] == 'active' ? 'warning' : 'success' ?>"
                           data-bs-toggle="tooltip" title="<?= $announcement['status'] == 'active' ? 'Deactivate' : 'Activate' ?>">
                          <i class="fas fa-<?= $announcement['status'] == 'active' ? 'pause' : 'play' ?>"></i>
                        </a>
                        <a href="?action=delete_announcement&id=<?= $announcement['id'] ?>" 
                           class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Are you sure you want to delete this announcement?')"
                           data-bs-toggle="tooltip" title="Delete">
                          <i class="fas fa-trash"></i>
                        </a>
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>

    <!-- SERMONS SECTION -->
    <section id="sermonsSection" class="d-none">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5>Manage Sermons</h5>
        <div>
          <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#sermonModal">
            <i class="fas fa-plus me-1"></i>Add Sermon
          </button>
        </div>
      </div>

      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Speaker</th>
                  <th>Date</th>
                  <th>Video</th>
                  <th>Audio</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($sermons)): ?>
                  <tr>
                    <td colspan="6" class="text-center py-4 text-muted">
                      No sermons found. <a href="#" data-bs-toggle="modal" data-bs-target="#sermonModal">Add your first sermon</a>
                    </td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($sermons as $sermon): ?>
                  <tr>
                    <td>
                      <strong><?= htmlspecialchars($sermon['title']) ?></strong>
                      <?php if ($sermon['description']): ?>
                        <br><small class="text-muted"><?= substr(htmlspecialchars($sermon['description']), 0, 100) ?>...</small>
                      <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($sermon['speaker']) ?></td>
                    <td><?= date('M j, Y', strtotime($sermon['sermon_date'])) ?></td>
                    <td>
                      <?php if ($sermon['video_url']): ?>
                        <a href="<?= htmlspecialchars($sermon['video_url']) ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                          <i class="fas fa-play"></i>
                        </a>
                      <?php else: ?>
                        <span class="text-muted">-</span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if ($sermon['audio_url']): ?>
                        <a href="<?= htmlspecialchars($sermon['audio_url']) ?>" target="_blank" class="btn btn-sm btn-outline-info">
                          <i class="fas fa-headphones"></i>
                        </a>
                      <?php else: ?>
                        <span class="text-muted">-</span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <div class="table-actions">
                        <a href="?action=delete_sermon&id=<?= $sermon['id'] ?>" 
                           class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Are you sure you want to delete this sermon?')"
                           data-bs-toggle="tooltip" title="Delete">
                          <i class="fas fa-trash"></i>
                        </a>
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>

    <!-- LIVE STREAM SECTION -->
    <section id="livestreamSection" class="d-none">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5>Live Stream Management</h5>
            <div>
                <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#livestreamModal">
                    <i class="fas fa-plus me-1"></i>Add Live Stream
                </button>
            </div>
        </div>

        <!-- Current Active Stream -->
        <?php if (!empty($active_livestream)): ?>
        <div class="card mb-4 border-success">
            <div class="card-header bg-success text-white">
                <i class="fas fa-broadcast-tower me-2"></i>Currently Live
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <h5><?= htmlspecialchars($active_livestream[0]['title']) ?></h5>
                        <p class="text-muted"><?= htmlspecialchars($active_livestream[0]['description']) ?></p>
                        <div class="d-flex gap-2">
                            <span class="badge bg-danger">LIVE NOW</span>
                            <span class="badge bg-secondary">Started: <?= date('M j, Y g:i A', strtotime($active_livestream[0]['updated_at'])) ?></span>
                        </div>
                    </div>
                    <div class="col-md-4 text-end">
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="stream_id" value="<?= $active_livestream[0]['id'] ?>">
                            <input type="hidden" name="is_live" value="0">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- All Live Streams -->
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Stream URL</th>
                                <th>Scheduled Time</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($livestreams)): ?>
                                <tr>
                                    <td colspan="5" class="text-center py-4 text-muted">
                                        No live streams found. <a href="#" data-bs-toggle="modal" data-bs-target="#livestreamModal">Add your first live stream</a>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($livestreams as $stream): ?>
                                <tr>
                                    <td>
                                        <strong><?= htmlspecialchars($stream['title']) ?></strong>
                                        <?php if ($stream['description']): ?>
                                            <br><small class="text-muted"><?= substr(htmlspecialchars($stream['description']), 0, 100) ?>...</small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <small class="text-muted"><?= htmlspecialchars($stream['stream_url']) ?></small>
                                    </td>
                                    <td>
                                        <?= $stream['scheduled_time'] ? date('M j, Y g:i A', strtotime($stream['scheduled_time'])) : 'Not scheduled' ?>
                                    </td>
                                 
                                    <td>
                                        <div class="table-actions">
                                            <?php if (!$stream['is_live']): ?>
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="stream_id" value="<?= $stream['id'] ?>">
                                                <input type="hidden" name="is_live" value="1">
                                                <button type="submit" name="update_livestream_status" 
                                                        class="btn btn-sm btn-success"
                                                        data-bs-toggle="tooltip" title="Go Live">
                                                    <i class="fas fa-play"></i>
                                                </button>
                                            </form>
                                            <?php else: ?>
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="stream_id" value="<?= $stream['id'] ?>">
                                                <input type="hidden" name="is_live" value="0">
                                        
                                            </form>
                                            <?php endif; ?>
                                            
                                            <a href="?action=delete_livestream&id=<?= $stream['id'] ?>" 
                                               class="btn btn-sm btn-outline-danger"
                                               onclick="return confirm('Are you sure you want to delete this live stream?')"
                                               data-bs-toggle="tooltip" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>

    <!-- PRAYER REQUESTS SECTION -->
    <section id="prayersSection" class="d-none">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5>Prayer Requests</h5>
        <div class="btn-group">
          <button class="btn btn-sm btn-outline-success" onclick="markAllAsPrayed()">
            <i class="fas fa-check-double me-1"></i>Mark All as Prayed
          </button>
          <button class="btn btn-sm btn-outline-danger" onclick="deleteAllPrayed()">
            <i class="fas fa-trash me-1"></i>Delete Prayed
          </button>
        </div>
      </div>

      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Contact</th>
                  <th>Category</th>
                  <th>Message</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($prayer_requests)): ?>
                  <tr>
                    <td colspan="7" class="text-center py-4 text-muted">No prayer requests found.</td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($prayer_requests as $prayer): ?>
                  <tr>
                    <td><?= htmlspecialchars($prayer['name']) ?></td>
                    <td>
                      <?php if ($prayer['email']): ?>
                        <div><small><?= htmlspecialchars($prayer['email']) ?></small></div>
                      <?php endif; ?>
                      <?php if ($prayer['phone']): ?>
                        <div><small><?= htmlspecialchars($prayer['phone']) ?></small></div>
                      <?php endif; ?>
                    </td>
                    <td>
                      <span class="badge bg-info"><?= htmlspecialchars($prayer['category']) ?></span>
                    </td>
                    <td>
                      <div style="max-width: 200px;">
                        <?= nl2br(htmlspecialchars(substr($prayer['message'], 0, 100))) ?>
                        <?php if (strlen($prayer['message']) > 100): ?>...<?php endif; ?>
                      </div>
                    </td>
                    <td><?= date('M j, Y g:i A', strtotime($prayer['submitted_at'])) ?></td>
                    <td>
                      <span class="badge bg-<?= $prayer['status'] == 'prayed' ? 'success' : 'secondary' ?>">
                        <?= ucfirst($prayer['status']) ?>
                      </span>
                    </td>
                    <td>
                      <div class="table-actions">
                        <button class="btn btn-sm btn-outline-success" 
                                onclick="markAsPrayed(<?= $prayer['id'] ?>)"
                                data-bs-toggle="tooltip" title="Mark as Prayed">
                          <i class="fas fa-check"></i>
                        </button>
                        <a href="?action=delete_prayer&id=<?= $prayer['id'] ?>" 
                           class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Are you sure you want to delete this prayer request?')"
                           data-bs-toggle="tooltip" title="Delete">
                          <i class="fas fa-trash"></i>
                        </a>
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>

    <!-- GALLERY SECTION -->
    <section id="gallerySection" class="d-none">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5>Gallery Management</h5>
        <div>
          <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#galleryModal">
            <i class="fas fa-plus me-1"></i>Upload Image
          </button>
        </div>
      </div>

      <div class="card">
        <div class="card-body">
          <?php if (empty($gallery_images)): ?>
            <div class="text-center py-4 text-muted">
              No images in gallery. 
              <a href="#" data-bs-toggle="modal" data-bs-target="#galleryModal">Upload your first image</a>
            </div>
          <?php else: ?>
            <div class="row g-3">
              <?php foreach ($gallery_images as $image): ?>
                <div class="col-md-4 col-lg-3">
                  <div class="card gallery-card shadow-sm border-0">
                    
                    <!-- Image Preview -->
                    <?php
                    $imgPath = $image['image_path'];

                    // Normalize path: remove duplicate "epiphany-admin/" if it exists
                    if (strpos($imgPath, 'epiphany-admin/') === 0) {
                      $imgPath = substr($imgPath, strlen('epiphany-admin/'));
                    }
                    ?>
                    <img 
                      src="<?php echo '../epiphany-admin/' . htmlspecialchars($imgPath); ?>" 
                      alt="<?php echo htmlspecialchars($image['title']); ?>" 
                      class="card-img-top"
                      style="height: 200px; object-fit: cover; border-radius: 8px 8px 0 0;"
                    >

                    <div class="card-body">
                      <h6 class="card-title mb-1 text-primary">
                        <?= htmlspecialchars($image['title']) ?>
                      </h6>
                      
                      <?php if (!empty($image['description'])): ?>
                        <p class="card-text small text-muted mb-2">
                          <?= substr(htmlspecialchars($image['description']), 0, 100) ?><?= strlen($image['description']) > 100 ? '...' : '' ?>
                        </p>
                      <?php endif; ?>
                      
                      <div class="d-flex justify-content-between align-items-center">
                        <span class="badge bg-secondary"><?= htmlspecialchars($image['category']) ?></span>
                        <a href="?action=delete_gallery_image&id=<?= $image['id'] ?>" 
                           class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Are you sure you want to delete this image?')">
                          <i class="fas fa-trash"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </section>

    <!-- DONATIONS SECTION -->
    <section id="paymentsSection" class="d-none">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5>Donations & Payments</h5>
        <div class="btn-group">
          <button class="btn btn-sm btn-outline-primary" id="refreshDonations">
            <i class="fas fa-sync-alt me-1"></i>Refresh
          </button>
          <button class="btn btn-sm btn-outline-success" id="exportDonations">
            <i class="fas fa-file-export me-1"></i>Export
          </button>
        </div>
      </div>

      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>Donor</th>
                  <th>Email</th>
                  <th>Amount</th>
                  <th>Method</th>
                  <th>Reference</th>
                  <th>Date</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($donations)): ?>
                  <tr>
                    <td colspan="7" class="text-center py-4 text-muted">No donations recorded yet.</td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($donations as $donation): ?>
                  <tr>
                    <td><?= htmlspecialchars($donation['donor_name']) ?></td>
                    <td><?= htmlspecialchars($donation['donor_email']) ?></td>
                    <td>₦<?= number_format($donation['amount'], 2) ?></td>
                    <td>
                      <span class="badge bg-info"><?= htmlspecialchars($donation['payment_method']) ?></span>
                    </td>
                    <td><code><?= htmlspecialchars($donation['reference']) ?></code></td>
                    <td><?= date('M j, Y', strtotime($donation['donation_date'])) ?></td>
                    <td>
                      <span class="badge badge-<?= $donation['status'] ?>">
                        <?= ucfirst($donation['status']) ?>
                      </span>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>

    <!-- USERS SECTION -->
    <section id="usersSection" class="d-none">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5>User Management</h5>
        <div>
          <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#userModal">
            <i class="fas fa-plus me-1"></i>Add User
          </button>
        </div>
      </div>

      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Joined</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($users)): ?>
                  <tr>
                    <td colspan="5" class="text-center py-4 text-muted">No users found.</td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($users as $user): ?>
                  <tr>
                    <td><?= htmlspecialchars($user['name']) ?></td>
                    <td><?= htmlspecialchars($user['email']) ?></td>
                    <td>
                      <span class="badge bg-<?= $user['role'] == 'admin' ? 'danger' : ($user['role'] == 'member' ? 'primary' : 'secondary') ?>">
                        <?= ucfirst($user['role']) ?>
                      </span>
                    </td>
                    <td><?= date('M j, Y', strtotime($user['created_at'])) ?></td>
                    <td>
                      <div class="table-actions">
                        <button class="btn btn-sm btn-outline-warning" onclick="editUser(<?= $user['id'] ?>)">
                          <i class="fas fa-edit"></i>
                        </button>
                        <a href="?action=delete_user&id=<?= $user['id'] ?>" 
                           class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Are you sure you want to delete this user?')">
                          <i class="fas fa-trash"></i>
                        </a>
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>

    <!-- SETTINGS SECTION -->
    <section id="settingsSection" class="d-none">
      <div class="card">
        <div class="card-body">
          <h5>Site Settings</h5>
          <form method="POST" class="row g-3 mt-2">
            <div class="col-md-6">
              <label class="form-label">Site Title</label>
              <input type="text" class="form-control" name="site_title" value="Anglican Church of Epiphany" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Default Email</label>
              <input type="email" class="form-control" name="site_email" value="info@epiphanychurch.org" required>
            </div>
            <div class="col-12">
              <label class="form-label">Church Address</label>
              <textarea class="form-control" name="site_address" rows="2" required>Lagos, Nigeria</textarea>
            </div>
            <div class="col-md-6">
              <label class="form-label">Phone Number</label>
              <input type="text" class="form-control" name="site_phone" value="+234 801 234 5678" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Service Times</label>
              <input type="text" class="form-control" name="site_service_times" value="Sunday Worship — 9:00 AM" required>
            </div>
            <div class="col-12">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="maintenanceMode">
                <label class="form-check-label" for="maintenanceMode">
                  Enable Maintenance Mode
                </label>
              </div>
            </div>
            <div class="col-12 text-end">
              <button type="submit" class="btn btn-primary" name="update_settings">
                <i class="fas fa-save me-1"></i>Save Settings
              </button>
            </div>
          </form>
        </div>
      </div>
    </section>
  </main>

  <!-- LIVESTREAM MODAL -->
  <div class="modal fade" id="livestreamModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <form method="POST" action="">
          <div class="modal-header">
            <h5 class="modal-title">Add Live Stream</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3">
              <label class="form-label">Stream Title *</label>
              <input type="text" class="form-control" name="stream_title" required 
                     placeholder="e.g., Sunday Service Live">
            </div>
            
            <div class="mb-3">
              <label class="form-label">Description</label>
              <textarea class="form-control" name="stream_description" rows="3" 
                        placeholder="Describe this live stream..."></textarea>
            </div>
            
            <div class="row">
              <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Stream URL *</label>
                  <input type="url" class="form-control" name="stream_url" required 
                         placeholder="https://youtube.com/live/... or rtmp://...">
                  <div class="form-text">YouTube, Facebook, or RTMP stream URL</div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Stream Key</label>
                  <input type="text" class="form-control" name="stream_key" 
                         placeholder="Your stream key (if required)">
                  <div class="form-text">Leave empty for platforms like YouTube</div>
                </div>
              </div>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Scheduled Time</label>
              <input type="datetime-local" class="form-control" name="scheduled_time">
              <div class="form-text">When this stream is scheduled to start</div>
            </div>
            
            <div class="form-check mb-3">
              <input class="form-check-input" type="checkbox" name="is_live" id="is_live" value="1">
              <label class="form-check-label" for="is_live">
                <strong>Start streaming immediately</strong>
              </label>
              <div class="form-text">This will mark the stream as live right now</div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary" name="add_livestream">
              <i class="fas fa-plus me-1"></i>Add Live Stream
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- ANNOUNCEMENT MODAL -->
  <div class="modal fade" id="announcementModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <form method="POST" id="announcementForm">
          <input type="hidden" name="announcement_id" id="announcement_id">
          <div class="modal-header">
            <h5 class="modal-title" id="announcementModalTitle">New Announcement</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-md-8">
                <div class="mb-3">
                  <label class="form-label">Title *</label>
                  <input type="text" class="form-control" name="title" id="announcementTitle" required>
                </div>
              </div>
              <div class="col-md-4">
                <div class="mb-3">
                  <label class="form-label">Category *</label>
                  <select class="form-select" name="category" id="announcementCategory" required>
                    <option value="">Select Category</option>
                    <option value="Event">Event</option>
                    <option value="Notice">Notice</option>
                    <option value="Update">Update</option>
                    <option value="General">General</option>
                    <option value="Urgent">Urgent</option>
                  </select>
                </div>
              </div>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Content *</label>
              <textarea class="form-control" name="content" id="announcementContent" rows="6" required></textarea>
            </div>
            
            <div class="row">
              <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Publish Date *</label>
                  <input type="date" class="form-control" name="publish_date" id="announcementPublishDate" required>
                </div>
              </div>
              <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Status *</label>
                  <select class="form-select" name="status" id="announcementStatus" required>
                    <option value="draft">Draft</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary" name="add_announcement" id="announcementSubmitBtn">
              <i class="fas fa-plus me-1"></i>Create Announcement
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- SERMON MODAL -->
  <div class="modal fade" id="sermonModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <form method="POST">
          <div class="modal-header">
            <h5 class="modal-title">Add New Sermon</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-md-8">
                <div class="mb-3">
                  <label class="form-label">Sermon Title *</label>
                  <input type="text" class="form-control" name="sermon_title" required>
                </div>
              </div>
              <div class="col-md-4">
                <div class="mb-3">
                  <label class="form-label">Speaker *</label>
                  <input type="text" class="form-control" name="sermon_speaker" required>
                </div>
              </div>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Description</label>
              <textarea class="form-control" name="sermon_description" rows="3"></textarea>
            </div>
            
            <div class="row">
              <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Video URL</label>
                  <input type="url" class="form-control" name="sermon_video_url" placeholder="https://youtube.com/...">
                </div>
              </div>
              <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Audio URL</label>
                  <input type="url" class="form-control" name="sermon_audio_url" placeholder="https://soundcloud.com/...">
                </div>
              </div>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Sermon Date *</label>
              <input type="date" class="form-control" name="sermon_date" required>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary" name="add_sermon">
              <i class="fas fa-plus me-1"></i>Add Sermon
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- GALLERY MODAL -->
  <div class="modal fade" id="galleryModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <form method="POST" enctype="multipart/form-data">
          <div class="modal-header">
            <h5 class="modal-title">Upload Image to Gallery</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3">
              <label class="form-label">Image Title *</label>
              <input type="text" class="form-control" name="image_title" required>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Description</label>
              <textarea class="form-control" name="image_description" rows="3"></textarea>
            </div>
            
            <div class="row">
              <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Category *</label>
                  <select class="form-select" name="image_category" required>
                    <option value="">Select Category</option>
                    <option value="Events">Events</option>
                    <option value="Services">Services</option>
                    <option value="Community">Community</option>
                    <option value="Building">Building</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>
              <div class="col-md-6">
                <div class="mb-3">
                  <label class="form-label">Image File *</label>
                  <input type="file" class="form-control" name="image_file" accept="image/*" required>
                  <div class="form-text">Supported formats: JPG, PNG, GIF, WEBP (Max: 5MB)</div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary" name="add_gallery_image">
              <i class="fas fa-upload me-1"></i>Upload Image
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- USER MODAL -->
  <div class="modal fade" id="userModal" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <form method="POST">
          <div class="modal-header">
            <h5 class="modal-title">Add New User</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3">
              <label class="form-label">Full Name *</label>
              <input type="text" class="form-control" name="user_name" required>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Email Address *</label>
              <input type="email" class="form-control" name="user_email" required>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Role *</label>
              <select class="form-select" name="user_role" required>
                <option value="member">Member</option>
                <option value="admin">Admin</option>
                <option value="guest">Guest</option>
              </select>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Password *</label>
              <input type="password" class="form-control" name="user_password" required>
              <div class="form-text">Minimum 6 characters</div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary" name="add_user">
              <i class="fas fa-plus me-1"></i>Add User
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Sidebar Toggle
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const mobileOverlay = document.getElementById('mobileOverlay');

    sidebarToggle.addEventListener('click', () => {
      sidebar.classList.toggle('collapsed');
      mainContent.classList.toggle('expanded');
      
      // Update toggle icon and text
      const icon = sidebarToggle.querySelector('i');
      const text = sidebarToggle.querySelector('span');
      if (sidebar.classList.contains('collapsed')) {
        icon.className = 'fas fa-chevron-right';
        text.textContent = 'Expand';
      } else {
        icon.className = 'fas fa-chevron-left';
        text.textContent = 'Collapse';
      }
    });

    // Mobile menu toggle
    mobileMenuToggle.addEventListener('click', () => {
      sidebar.classList.toggle('mobile-open');
      mobileOverlay.classList.toggle('active');
    });

    mobileOverlay.addEventListener('click', () => {
      sidebar.classList.remove('mobile-open');
      mobileOverlay.classList.remove('active');
    });

    // Section Navigation
    document.querySelectorAll('.sidebar .nav-link[data-section]').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const section = link.getAttribute('data-section');
        showSection(section);
        
        // Close mobile menu on selection
        if (window.innerWidth < 992) {
          sidebar.classList.remove('mobile-open');
          mobileOverlay.classList.remove('active');
        }
      });
    });

    function showSection(section) {
      // Hide all sections
      document.querySelectorAll('main > section').forEach(sec => {
        sec.classList.add('d-none');
      });
      
      // Remove active class from all nav links
      document.querySelectorAll('.sidebar .nav-link').forEach(link => {
        link.classList.remove('active');
      });
      
      // Show selected section and activate nav link
      document.getElementById(section + 'Section')?.classList.remove('d-none');
      document.querySelector(`.sidebar .nav-link[data-section="${section}"]`)?.classList.add('active');
      
      // Update section title and description
      updateSectionInfo(section);
    }

    function updateSectionInfo(section) {
      const titles = {
        dashboard: 'Dashboard',
        announcements: 'Announcements',
        prayers: 'Prayer Requests',
        sermons: 'Sermons',
        livestream: 'Live Stream',
        gallery: 'Gallery',
        payments: 'Donations & Payments',
        users: 'User Management',
        settings: 'Settings'
      };
      
      const descriptions = {
        dashboard: 'Welcome back',
        announcements: 'church announcements and updates',
        prayers: 'manage prayer requests from members',
        sermons: 'manage sermon recordings',
        livestream: 'live streaming settings',
        gallery: 'church photo gallery',
        payments: 'donations and payments',
        users: 'member accounts and permissions',
        settings: ' church website settings'
      };
      
      document.getElementById('sectionTitle').textContent = titles[section] || 'Dashboard';
      document.getElementById('sectionDescription').textContent = descriptions[section] || '';
    }

    // Announcement Functions
    function editAnnouncement(id) {
      // In a real implementation, you would fetch the announcement data via AJAX
      alert('Edit announcement with ID: ' + id + '\n\nIn a real implementation, this would load the announcement data into the modal for editing.');
    }

    function markAsPrayed(id) {
      if (confirm('Mark this prayer request as prayed?')) {
        window.location.href = '?action=mark_prayed&id=' + id;
      }
    }

    function markAllAsPrayed() {
      if (confirm('Mark all prayer requests as prayed?')) {
        // This would typically be handled via AJAX or a separate PHP endpoint
        alert('All prayer requests marked as prayed (this would be implemented with proper backend logic)');
      }
    }

    function deleteAllPrayed() {
      if (confirm('Delete all prayed requests? This action cannot be undone.')) {
        // This would typically be handled via AJAX or a separate PHP endpoint
        alert('All prayed requests deleted (this would be implemented with proper backend logic)');
      }
    }

    function editUser(id) {
      alert('Edit user with ID: ' + id + '\n\nIn a real implementation, this would load the user data into a modal for editing.');
    }

    function editLivestream(id) {
      alert('Edit live stream with ID: ' + id + '\n\nIn a real implementation, this would load the stream data into the modal for editing.');
    }

    // Initialize date fields to today
    document.getElementById('announcementPublishDate').valueAsDate = new Date();
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Show dashboard by default
    showSection('dashboard');
  </script>
</body>
</html>