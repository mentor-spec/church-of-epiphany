<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Church Donations | Anglican Church of Epiphany</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://js.paystack.co/v1/inline.js"></script>
  <style>
    :root {
      --primary-color: #28a745;
      --primary-hover: #218838;
      --dark-bg: #121212;
      --dark-card: #2c2c2c;
      --light-text: #f1f1f1;
    }
    
    body {
      transition: background-color 0.3s, color 0.3s;
    }
    
    body.dark-mode {
      background-color: var(--dark-bg);
      color: var(--light-text);
    }
    
    .donation-section {
      padding: 60px 20px;
      background-color: #f8f9fa;
      min-height: 80vh;
    }
    
    body.dark-mode .donation-section {
      background-color: var(--dark-bg);
    }
    
    .donation-card {
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
      transition: all 0.3s ease;
    }
    
    body.dark-mode .donation-card {
      background: var(--dark-card);
      color: var(--light-text);
    }
    
    .donate-btn {
      background-color: var(--primary-color);
      color: white;
      border: none;
      padding: 12px 30px;
      font-size: 1.1rem;
      border-radius: 8px;
      width: 100%;
      transition: background 0.3s;
    }
    
    .donate-btn:hover {
      background-color: var(--primary-hover);
    }
    
    .donation-options {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-bottom: 20px;
    }
    
    .donation-option {
      flex: 1;
      min-width: 100px;
      text-align: center;
      padding: 10px;
      border: 2px solid #e0e0e0;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.2s;
    }
    
    body.dark-mode .donation-option {
      border-color: #444;
    }
    
    .donation-option:hover {
      border-color: var(--primary-color);
    }
    
    .donation-option.active {
      background-color: var(--primary-color);
      color: white;
      border-color: var(--primary-color);
    }
    
    .theme-toggle {
      background: none;
      border: 1px solid white;
      color: white;
      border-radius: 20px;
      padding: 5px 15px;
      transition: all 0.3s;
    }
    
    body.dark-mode .theme-toggle {
      border-color: var(--light-text);
      color: var(--light-text);
    }
    
    .theme-toggle:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    
    .success-message {
      display: none;
      background-color: #d4edda;
      color: #155724;
      padding: 15px;
      border-radius: 8px;
      margin-top: 20px;
    }
    
    body.dark-mode .success-message {
      background-color: #1e4620;
      color: #c8e6c9;
    }
    
    .error-message {
      display: none;
      background-color: #f8d7da;
      color: #721c24;
      padding: 15px;
      border-radius: 8px;
      margin-top: 20px;
    }
    
    body.dark-mode .error-message {
      background-color: #3c1a1d;
      color: #f5c6cb;
    }
    .but{
      text-decoration: none;
      color: white;
      margin-left: 20px;
      margin-top: 20px;
      border-radius: 8px;
      background-color: var(--primary-color);
      padding: 10px 15px;
      border: none;
    }
  </style>
</head>
<body>
  <header class="p-3 bg-primary text-white text-center">
    <div class="container">
      <h1>Anglican Church of Epiphany Awka</h1>
      <p class="lead">Supporting our mission and ministry</p>
      <button class="btn theme-toggle" onclick="toggleDarkMode()">
        <span id="theme-icon">🌞</span> Toggle Theme
      </button>
    </div>
  </header>
 <a class="but" href="index.php">BACK</a>
  <main class="container mt-5">
    <section class="donation-section">
      <div class="container">
        <div class="text-center mb-5">
          <h2>Support Our Ministry</h2>
          <p class="lead">Your generous donation helps us spread the gospel and serve our community.</p>
        </div>

        <div class="row justify-content-center">
          <div class="col-md-8 col-lg-6">
            <div class="donation-card">
              <form id="donationForm" onsubmit="payWithPaystack(event)">
                <div class="mb-3">
                  <label for="donorName" class="form-label">Full Name</label>
                  <input type="text" class="form-control" id="donorName" placeholder="Enter your full name" required>
                </div>

                <div class="mb-3">
                  <label for="donorEmail" class="form-label">Email Address</label>
                  <input type="email" class="form-control" id="donorEmail" placeholder="Enter your email" required>
                </div>
                
                <div class="mb-3">
                  <label for="donorPhone" class="form-label">Phone Number (Optional)</label>
                  <input type="tel" class="form-control" id="donorPhone" placeholder="Enter your phone number">
                </div>

                <div class="mb-4">
                  <label for="amount" class="form-label">Donation Amount (₦)</label>
                  <input type="number" class="form-control" id="amount" placeholder="e.g. 5000" min="100" required>
                  
                  <div class="donation-options mt-2">
                    <div class="donation-option" data-amount="1000">₦1,000</div>
                    <div class="donation-option" data-amount="2000">₦2,000</div>
                    <div class="donation-option" data-amount="5000">₦5,000</div>
                    <div class="donation-option" data-amount="10000">₦10,000</div>
                    <div class="donation-option" data-amount="20000">₦20,000</div>
                    <div class="donation-option" data-amount="50000">₦50,000</div>
                  </div>
                </div>
                
                <div class="mb-3">
                  <label for="purpose" class="form-label">Donation Purpose (Optional)</label>
                  <select class="form-select" id="purpose">
                    <option value="General Offering">General Offering</option>
                    <option value="Building Fund">Building Fund</option>
                    <option value="Missions">Missions</option>
                    <option value="Outreach Programs">Outreach Programs</option>
                    <option value="Pastoral Support">Pastoral Support</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <button type="submit" class="donate-btn" id="donateButton">
                  <span id="buttonText">Donate Now</span>
                  <span id="buttonSpinner" class="spinner-border spinner-border-sm" role="status" aria-hidden="true" style="display: none;"></span>
                </button>
                
                <div id="successMessage" class="success-message">
                  <i class="fas fa-check-circle"></i> Thank you for your donation! Your transaction was successful.
                </div>
                
                <div id="errorMessage" class="error-message">
                  <i class="fas fa-exclamation-circle"></i> There was an error processing your donation. Please try again.
                </div>
              </form>
            </div>
            
            <div class="mt-4 text-center">
              <p><small>Your donation is securely processed through Paystack. We do not store your card details.</small></p>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer class="text-center py-4 bg-dark text-white">
    <div class="container">
      <p>&copy; 2025 Anglican Church of Epiphany Awka. All Rights Reserved.</p>
      <p class="mb-0"><small>Contact: +234 801 234 5678 | info@epiphanychurch.org</small></p>
    </div>
  </footer>

  <script>
    // Dark mode toggle
    function toggleDarkMode() {
      document.body.classList.toggle('dark-mode');
      const themeIcon = document.getElementById('theme-icon');
      themeIcon.textContent = document.body.classList.contains('dark-mode') ? '🌒' : '🌞';
      
      // Save theme preference
      localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
    }
    
    // Load saved theme preference
    document.addEventListener('DOMContentLoaded', function() {
      const savedTheme = localStorage.getItem('theme');
      if (savedTheme === 'dark') {
        document.body.classList.add('dark-mode');
        document.getElementById('theme-icon').textContent = '🌒';
      }
      
      // Set up donation option buttons
      document.querySelectorAll('.donation-option').forEach(option => {
        option.addEventListener('click', function() {
          // Remove active class from all options
          document.querySelectorAll('.donation-option').forEach(opt => {
            opt.classList.remove('active');
          });
          
          // Add active class to clicked option
          this.classList.add('active');
          
          // Set the amount in the input field
          document.getElementById('amount').value = this.getAttribute('data-amount');
        });
      });
    });

    // Paystack Payment Integration
    function payWithPaystack(event) {
      event.preventDefault();
      
      // Show loading state
      const donateButton = document.getElementById('donateButton');
      const buttonText = document.getElementById('buttonText');
      const buttonSpinner = document.getElementById('buttonSpinner');
      
      buttonText.textContent = 'Processing...';
      buttonSpinner.style.display = 'inline-block';
      donateButton.disabled = true;
      
      // Hide any previous messages
      document.getElementById('successMessage').style.display = 'none';
      document.getElementById('errorMessage').style.display = 'none';

      let handler = PaystackPop.setup({
        key: 'pk_test_81ab7beccb202713fbacb2fb0dea8d87022abbba', // Replace with your Paystack Public Key
        email: document.getElementById('donorEmail').value,
        amount: document.getElementById('amount').value * 100, // Amount in kobo
        currency: 'NGN',
        ref: 'EPIPHANY_' + Math.floor((Math.random() * 1000000000) + 1), // Unique transaction reference
        metadata: {
          custom_fields: [
            {
              display_name: "Donor Name",
              variable_name: "donor_name",
              value: document.getElementById('donorName').value
            },
            {
              display_name: "Phone",
              variable_name: "phone",
              value: document.getElementById('donorPhone').value || 'Not provided'
            },
            {
              display_name: "Purpose",
              variable_name: "purpose",
              value: document.getElementById('purpose').value
            }
          ]
        },
        callback: function(response) {
          // Payment successful - send data to server
          const donationData = {
            reference: response.reference,
            donorName: document.getElementById('donorName').value,
            donorEmail: document.getElementById('donorEmail').value,
            donorPhone: document.getElementById('donorPhone').value || '',
            amount: document.getElementById('amount').value,
            purpose: document.getElementById('purpose').value,
            status: 'success'
          };
          
          // Send data to server for database insertion
          fetch('save_donation.php', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(donationData)
          })
          .then(response => response.json())
          .then(data => {
            if (data.success) {
              // Show success message
              document.getElementById('successMessage').style.display = 'block';
              
              // Reset form after successful donation
              setTimeout(() => {
                document.getElementById('donationForm').reset();
                document.querySelectorAll('.donation-option').forEach(opt => {
                  opt.classList.remove('active');
                });
              }, 2000);
            } else {
              // Show error message if database insertion failed
              document.getElementById('errorMessage').style.display = 'block';
              console.error('Database error:', data.message);
            }
          })
          .catch(error => {
            console.error('Error:', error);
            document.getElementById('errorMessage').style.display = 'block';
          })
          .finally(() => {
            // Reset button state
            buttonText.textContent = 'Donate Now';
            buttonSpinner.style.display = 'none';
            donateButton.disabled = false;
          });
        },
        onClose: function() {
          // Payment window closed
          buttonText.textContent = 'Donate Now';
          buttonSpinner.style.display = 'none';
          donateButton.disabled = false;
          alert('Donation process canceled.');
        }
      });
      handler.openIframe();
    }
  </script>
</body>
</html>