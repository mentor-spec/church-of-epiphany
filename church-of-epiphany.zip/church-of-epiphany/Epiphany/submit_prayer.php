<?php
// submit_prayer.php

// Include your database connection file
require_once 'db.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    
    // Set current timestamp
    $submitted_at = date('Y-m-d H:i:s');
    
    // Prepare SQL statement
    $sql = "INSERT INTO prayer_requests (name, email, phone, category, message, submitted_at) 
            VALUES ('$name', '$email', '$phone', '$category', '$message', '$submitted_at')";
    
    // Execute query
    if (mysqli_query($conn, $sql)) {
        // Success - redirect with success message
        header("Location: " . $_SERVER['HTTP_REFERER'] . "?prayer_status=success");
        exit();
    } else {
        // Error - redirect with error message
        header("Location: " . $_SERVER['HTTP_REFERER'] . "?prayer_status=error");
        exit();
    }
    
    // Close connection
    mysqli_close($conn);
} else {
    // If not a POST request, redirect back
    header("Location: " . $_SERVER['HTTP_REFERER']);
    exit();
}
?>