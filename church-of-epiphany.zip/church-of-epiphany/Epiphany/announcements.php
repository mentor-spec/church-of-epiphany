<?php
// announcements.php
require_once 'db.php';

// Get all active announcements
$sql = "SELECT * FROM announcements 
        WHERE status = 'active' 
        AND publish_date <= CURDATE() 
        ORDER BY publish_date DESC, created_at DESC";

$result = mysqli_query($conn, $sql);
$all_announcements = [];
if ($result) {
    $all_announcements = mysqli_fetch_all($result, MYSQLI_ASSOC);
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Announcements - Epiphany Church</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        .announcement-card {
            transition: transform 0.2s;
            border-left: 4px solid #6c63ff;
        }
        .announcement-card:hover {
            transform: translateY(-3px);
        }
        .urgent-card {
            border-left-color: #dc3545;
            background-color: #fff5f5;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-church me-2"></i>Epiphany Church
            </a>
            <a href="index.php" class="btn btn-outline-light btn-sm">
                <i class="fas fa-arrow-left me-1"></i>Back to Home
            </a>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row">
            <div class="col-12">
                <h1 class="mb-4">Church Announcements</h1>
                
                <?php if (empty($all_announcements)): ?>
                    <div class="alert alert-info text-center py-5">
                        <i class="fas fa-bullhorn fa-3x mb-3 text-muted"></i>
                        <h4 class="text-muted">No Announcements Available</h4>
                        <p class="text-muted">There are no announcements at the moment. Please check back later.</p>
                    </div>
                <?php else: ?>
                    <div class="row g-4">
                        <?php foreach ($all_announcements as $announcement): ?>
                            <div class="col-lg-6">
                                <div class="card shadow-sm h-100 announcement-card <?= $announcement['category'] == 'Urgent' ? 'urgent-card' : '' ?>">
                                    <div class="card-body">
                                        <?php
                                        $badge_class = 'bg-secondary';
                                        switch($announcement['category']) {
                                            case 'Urgent': $badge_class = 'bg-danger'; break;
                                            case 'Event': $badge_class = 'bg-primary'; break;
                                            case 'Update': $badge_class = 'bg-info'; break;
                                            case 'Notice': $badge_class = 'bg-warning text-dark'; break;
                                            case 'General': $badge_class = 'bg-success'; break;
                                        }
                                        ?>
                                        <span class="badge <?= $badge_class ?> mb-2"><?= htmlspecialchars($announcement['category']) ?></span>
                                        
                                        <h4 class="card-title"><?= htmlspecialchars($announcement['title']) ?></h4>
                                        <p class="card-text"><?= nl2br(htmlspecialchars($announcement['content'])) ?></p>
                                        
                                        <div class="mt-3 pt-3 border-top">
                                            <small class="text-muted">
                                                <i class="fas fa-calendar-alt me-1"></i>
                                                Published: <?= date('F j, Y', strtotime($announcement['publish_date'])) ?>
                                            </small>
                                            <?php if ($announcement['created_at'] != $announcement['publish_date']): ?>
                                                <br>
                                                <small class="text-muted">
                                                    <i class="fas fa-clock me-1"></i>
                                                    Posted: <?= date('F j, Y g:i A', strtotime($announcement['created_at'])) ?>
                                                </small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>