<?php
// save_donation.php

// Include your database connection file
require_once 'db.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the raw POST data
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    // Validate required fields
    if (!isset($data['reference']) || !isset($data['donorName']) || 
        !isset($data['donorEmail']) || !isset($data['amount'])) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        exit;
    }
    
    // Sanitize data
    $reference = mysqli_real_escape_string($conn, $data['reference']);
    $donorName = mysqli_real_escape_string($conn, $data['donorName']);
    $donorEmail = mysqli_real_escape_string($conn, $data['donorEmail']);
    $donorPhone = mysqli_real_escape_string($conn, $data['donorPhone']);
    $amount = mysqli_real_escape_string($conn, $data['amount']);
    $purpose = mysqli_real_escape_string($conn, $data['purpose']);
    $status = mysqli_real_escape_string($conn, $data['status']);
    
    // Set current timestamp
    $donationDate = date('Y-m-d H:i:s');
    
    // Prepare SQL statement
    $sql = "INSERT INTO donations (reference, donor_name, donor_email, donor_phone, amount, purpose, status, donation_date) 
            VALUES ('$reference', '$donorName', '$donorEmail', '$donorPhone', '$amount', '$purpose', '$status', '$donationDate')";
    
    // Execute query
    if (mysqli_query($conn, $sql)) {
        echo json_encode(['success' => true, 'message' => 'Donation record saved successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . mysqli_error($conn)]);
    }
    
    // Close connection
    mysqli_close($conn);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>