<?php
// sermons.php
require_once 'db.php';

// Get all sermons
$sql = "SELECT * FROM sermons ORDER BY sermon_date DESC";
$result = mysqli_query($conn, $sql);
$all_sermons = [];
if ($result) {
    $all_sermons = mysqli_fetch_all($result, MYSQLI_ASSOC);
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Sermons - Epiphany Church</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        .sermon-card {
            transition: transform 0.3s ease;
            border: none;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .sermon-card:hover {
            transform: translateY(-5px);
        }
        .video-placeholder {
            background: linear-gradient(45deg, #1a1a1a, #2d2d2d);
            height: 200px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
    </style>
</head>
<body class="bg-dark text-light">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-church me-2"></i>Epiphany Church
            </a>
            <a href="index.php" class="btn btn-outline-light btn-sm">
                <i class="fas fa-arrow-left me-1"></i>Back to Home
            </a>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row">
            <div class="col-12 text-center mb-5">
                <h1 class="text-warning">Church Sermons</h1>
                <p class="lead">Watch and listen to inspiring messages from our services</p>
            </div>
        </div>

        <?php if (empty($all_sermons)): ?>
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="card bg-secondary text-center py-5">
                        <div class="card-body">
                            <i class="fas fa-video fa-3x text-muted mb-3"></i>
                            <h4 class="text-muted">No Sermons Available</h4>
                            <p class="text-muted">Check back later for sermon recordings.</p>
                            <a href="index.php" class="btn btn-primary">Return to Homepage</a>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($all_sermons as $sermon): ?>
                    <div class="col-lg-6">
                        <div class="card bg-secondary text-light sermon-card h-100">
                            <div class="card-body">
                                <h4 class="card-title text-warning"><?= htmlspecialchars($sermon['title']) ?></h4>
                                
                                <div class="mb-3">
                                    <span class="badge bg-primary me-2">
                                        <i class="fas fa-user me-1"></i><?= htmlspecialchars($sermon['speaker']) ?>
                                    </span>
                                    <span class="badge bg-dark">
                                        <i class="fas fa-calendar me-1"></i><?= date('F j, Y', strtotime($sermon['sermon_date'])) ?>
                                    </span>
                                </div>
                                
                                <?php if ($sermon['description']): ?>
                                    <p class="card-text"><?= nl2br(htmlspecialchars($sermon['description'])) ?></p>
                                <?php endif; ?>
                                
                                <div class="mt-3">
                                    <?php if ($sermon['video_url']): ?>
                                        <a href="<?= htmlspecialchars($sermon['video_url']) ?>" 
                                           target="_blank" 
                                           class="btn btn-warning me-2">
                                            <i class="fas fa-play me-1"></i>Watch Video
                                        </a>
                                    <?php endif; ?>
                                    
                                    <?php if ($sermon['audio_url']): ?>
                                        <a href="<?= htmlspecialchars($sermon['audio_url']) ?>" 
                                           target="_blank" 
                                           class="btn btn-outline-light">
                                            <i class="fas fa-headphones me-1"></i>Listen Audio
                                        </a>
                                    <?php endif; ?>
                                    
                                    <?php if (!$sermon['video_url'] && !$sermon['audio_url']): ?>
                                        <span class="text-muted">
                                            <i class="fas fa-info-circle me-1"></i>Media coming soon
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>