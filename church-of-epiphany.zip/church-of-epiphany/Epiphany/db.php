<?php
session_start();

$conn =  mysqli_connect("localhost", "root", "", "churchs") or die("unable to connect...");




?>