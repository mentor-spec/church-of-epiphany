<?php
require_once "db.php"; // adjust if your db.php path differs
// Fetch gallery items
$sql = "SELECT * FROM gallery ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Church Gallery - Epiphany Church</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary: #6c63ff;
      --secondary: #8b5cf6;
      --accent: #10b981;
      --gold: #d4af37;
      --dark: #1e293b;
      --light: #f8fafc;
    }

    body {
      font-family: 'Inter', sans-serif;
      background: #f1f5f9;
      min-height: 100vh;
      margin: 0;
      padding: 0;
    }

    .church-header {
      background: rgba(30, 41, 59, 0.95);
      backdrop-filter: blur(10px);
      padding: 1rem 0;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }

    .church-brand {
      font-family: 'Playfair Display', serif;
      font-weight: 700;
      font-size: 1.8rem;
      color: white;
      text-decoration: none;
    }

    .church-brand i {
      color: var(--gold);
    }

    .main-container {
      backdrop-filter: blur(10px);
      margin: 2rem auto;
      overflow: hidden;
      max-width: 1400px;
    }

    .page-header {
     background-image: url('./church.jpg');
     background-size: cover;
     background-position: center;
     color: white;
      padding: 4rem 2rem;
      text-align: center;
      position: relative;
      overflow: hidden;
    }

    .page-header::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" fill="%23ffffff" opacity="0.1"><path d="M500 50L550 25L600 50L650 25L700 50L750 25L800 50L850 25L900 50L950 25L1000 50V100H0V50Z"/></svg>');
      background-size: cover;
    }

    .page-title {
      font-family: 'Playfair Display', serif;
      font-weight: 700;
      font-size: 3.5rem;
      margin-bottom: 1rem;
      position: relative;
    }

    .page-subtitle {
      font-size: 1.3rem;
      opacity: 0.9;
      font-weight: 300;
      position: relative;
    }

    .gallery-container {
      padding: 3rem 2rem;
    }

    .gallery-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 2rem;
      margin-top: 2rem;
    }

    .gallery-card {
      background: white;
      border-radius: 16px;
      overflow: hidden;
      box-shadow: 0 8px 25px rgba(0,0,0,0.1);
      transition: all 0.3s ease;
      border: none;
      position: relative;
    }

    .gallery-card:hover {
      transform: translateY(-12px);
      box-shadow: 0 20px 40px rgba(0,0,0,0.15);
    }

    .gallery-image {
      width: 100%;
      height: 250px;
      object-fit: cover;
      transition: transform 0.3s ease;
      display: block;
    }

    .gallery-card:hover .gallery-image {
      transform: scale(1.08);
    }

    .gallery-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(transparent, rgba(0,0,0,0.7));
      display: flex;
      align-items: flex-end;
      padding: 1.5rem;
      opacity: 0;
      transition: opacity 0.3s ease;
    }

    .gallery-card:hover .gallery-overlay {
      opacity: 1;
    }

    .gallery-caption {
      color: white;
      text-align: left;
    }

    .gallery-caption h5 {
      font-weight: 600;
      margin-bottom: 0.5rem;
      font-size: 1.2rem;
    }

    .gallery-caption p {
      font-size: 0.9rem;
      opacity: 0.9;
      margin-bottom: 0.5rem;
    }

    .gallery-category {
      background: var(--gold);
      color: white;
      padding: 0.3rem 0.8rem;
      border-radius: 20px;
      font-size: 0.8rem;
      font-weight: 500;
      display: inline-block;
    }

    .card-body {
      padding: 1.5rem;
    }

    .card-title {
      font-weight: 600;
      color: var(--dark);
      margin-bottom: 0.5rem;
      font-size: 1.1rem;
    }

    .card-text {
      color: #64748b;
      font-size: 0.9rem;
      line-height: 1.5;
    }

    .stats-card {
      background: white;
      border-radius: 16px;
      padding: 2rem;
      box-shadow: 0 8px 25px rgba(0,0,0,0.1);
      text-align: center;
      margin-bottom: 2rem;
    }

    .stats-number {
      font-size: 3rem;
      font-weight: 700;
      color: var(--primary);
      margin-bottom: 0.5rem;
    }

    .stats-label {
      color: #64748b;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      font-size: 0.9rem;
    }

    .empty-state {
      padding: 4rem 2rem;
      text-align: center;
    }

    .empty-state-icon {
      font-size: 4rem;
      color: #cbd5e1;
      margin-bottom: 1.5rem;
    }

    .back-btn {
      background: rgba(255, 255, 255, 0.2);
      border: 2px solid rgba(255, 255, 255, 0.3);
      color: white;
      border-radius: 50px;
      padding: 0.7rem 2rem;
      font-weight: 500;
      transition: all 0.3s ease;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
    }

    .back-btn:hover {
      background: rgba(255, 255, 255, 0.3);
      border-color: rgba(255, 255, 255, 0.5);
      color: white;
      transform: translateX(-5px);
    }

    .church-footer {
      background: rgba(30, 41, 59, 0.95);
      color: white;
      text-align: center;
      padding: 2rem;
      margin-top: 3rem;
    }

   /* Responsive Design */
@media (max-width: 1200px) {
  .gallery-grid {
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 1.5rem;
  }
}

@media (max-width: 768px) {
  .page-title {
    font-size: 2.5rem;
  }
  
  .page-header {
    padding: 3rem 1rem;
  }
  
  .gallery-container {
    padding: 2rem 1rem;
  }
  
  .gallery-grid {
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 1rem;
  }
  
  .gallery-image {
    height: 200px;
  }
  
  .main-container {
    margin: 1rem;
    border-radius: 15px;
  }
}

@media (max-width: 576px) {
  .gallery-grid {
    grid-template-columns: repeat(2, 1fr);
    gap: 1rem;
  }
  
  .gallery-image {
    height: 180px;
  }
  
  .page-title {
    font-size: 2rem;
  }
  
  .stats-number {
    font-size: 2.5rem;
  }
  
  .card-body {
    padding: 1rem;
  }
  
  .card-title {
    font-size: 1rem;
  }
  
  .card-text {
    font-size: 0.8rem;
  }
  
  .gallery-caption h5 {
    font-size: 1rem;
  }
  
  .gallery-caption p {
    font-size: 0.8rem;
  }
}

    /* Animation */
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .gallery-card {
      animation: fadeInUp 0.6s ease forwards;
    }

    .gallery-card:nth-child(1) { animation-delay: 0.1s; }
    .gallery-card:nth-child(2) { animation-delay: 0.2s; }
    .gallery-card:nth-child(3) { animation-delay: 0.3s; }
    .gallery-card:nth-child(4) { animation-delay: 0.4s; }
    .gallery-card:nth-child(5) { animation-delay: 0.5s; }
    .gallery-card:nth-child(6) { animation-delay: 0.6s; }
  </style>
</head>

<body>
  <!-- Church Header -->
  <header class="church-header">
    <div class="container">
      <div class="d-flex justify-content-between align-items-center">
        <a href="index.php" class="church-brand">
          <i class="fas fa-church me-2"></i>Epiphany Church
        </a>
        <a href="index.php" class="back-btn">
          <i class="fas fa-arrow-left"></i> Back to Home
        </a>
      </div>
    </div>
  </header>

  <!-- Main Content -->
  <div class="main-container">
    <!-- Page Header -->
    <div class="page-header">
      <h1 class="page-title">Church Gallery</h1>
      <p class="page-subtitle">Capturing precious moments from our faith community</p>
    </div>

    <div class="gallery-container">
      <!-- Statistics -->
      <div class="row justify-content-center mb-5">
        <div class="col-md-3">
          <div class="stats-card">
            <div class="stats-number"><?= $result->num_rows ?? 0 ?></div>
            <div class="stats-label">Total Photos</div>
          </div>
        </div>
      </div>

      <?php if ($result && $result->num_rows > 0): ?>
        <div class="gallery-grid">
          <?php while ($row = $result->fetch_assoc()): ?>
            <?php
              // Extract just the file name to avoid path issues
              $imageFile = basename($row['image_path']);
              $imageSrc = "../epiphany-admin/uploads/gallery/" . $imageFile;
            ?>
            <div class="gallery-card">
              <div class="position-relative overflow-hidden">
                <img src="<?php echo htmlspecialchars($imageSrc); ?>" 
                     class="gallery-image" 
                     alt="<?php echo htmlspecialchars($row['title']); ?>"
                     onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjI1MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjhmYWZjIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxNCIgZmlsbD0jOTlhNmFmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iMC4zZW0iPkltYWdlIE5vdCBGb3VuZDwvdGV4dD48L3N2Zz4='">
                <div class="gallery-overlay">
                  <div class="gallery-caption">
                    <h5><?php echo htmlspecialchars($row['title']); ?></h5>
                    <?php if (!empty($row['description'])): ?>
                      <p><?php echo htmlspecialchars(substr($row['description'], 0, 100)); ?>...</p>
                    <?php endif; ?>
                    <?php if (!empty($row['category'])): ?>
                      <span class="gallery-category"><?php echo htmlspecialchars($row['category']); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              <div class="card-body">
                <h5 class="card-title"><?php echo htmlspecialchars($row['title']); ?></h5>
                <?php if (!empty($row['description'])): ?>
                  <p class="card-text"><?php echo htmlspecialchars(substr($row['description'], 0, 150)); ?>...</p>
                <?php endif; ?>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
      <?php else: ?>
        <div class="empty-state">
          <div class="empty-state-icon">
            <i class="fas fa-images"></i>
          </div>
          <h3 class="text-muted mb-3">Gallery Coming Soon</h3>
          <p class="text-muted mb-4">We're preparing to share wonderful moments from our church community.</p>
          <a href="index.php" class="btn btn-primary px-4 py-2">
            <i class="fas fa-home me-2"></i>Return to Homepage
          </a>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Church Footer -->
  <footer class="church-footer">
    <div class="container">
      <p class="mb-0">&copy; <?php echo date('Y'); ?> Epiphany Church. All rights reserved.</p>
      <p class="small mt-2 opacity-75">Capturing God's grace through our community moments</p>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Add smooth loading animation
    document.addEventListener('DOMContentLoaded', function() {
      const cards = document.querySelectorAll('.gallery-card');
      cards.forEach((card, index) => {
        card.style.opacity = '0';
        setTimeout(() => {
          card.style.transition = 'all 0.6s ease';
          card.style.opacity = '1';
        }, index * 100);
      });
    });

    // Add image error handling
    document.querySelectorAll('.gallery-image').forEach(img => {
      img.addEventListener('error', function() {
        this.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjI1MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjhmYWZjIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxNCIgZmlsbD0jOTlhNmFmIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iMC4zZW0iPkltYWdlIE5vdCBGb3VuZDwvdGV4dD48L3N2Zz4=';
      });
    });
  </script>
</body>
</html>