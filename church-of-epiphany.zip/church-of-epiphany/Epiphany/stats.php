<?php
require_once '../db.php';

$stats = [
    'sermons' => 0,
    'announcements' => 0,
    'prayers' => 0,
    'users' => 0
];

// Get sermons count
$result = $conn->query("SELECT COUNT(*) as count FROM sermons");
if ($result) $stats['sermons'] = $result->fetch_assoc()['count'];

// Get announcements count
$result = $conn->query("SELECT COUNT(*) as count FROM announcements");
if ($result) $stats['announcements'] = $result->fetch_assoc()['count'];

// Get prayer requests count
$result = $conn->query("SELECT COUNT(*) as count FROM prayer_requests");
if ($result) $stats['prayers'] = $result->fetch_assoc()['count'];

// Get users count
$result = $conn->query("SELECT COUNT(*) as count FROM users");
if ($result) $stats['users'] = $result->fetch_assoc()['count'];

echo json_encode(['success' => true, 'data' => $stats]);
$conn->close();
?>