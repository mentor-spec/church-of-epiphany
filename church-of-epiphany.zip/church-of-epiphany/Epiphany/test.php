<?php
// test-api.php - Place this in the same folder as your HTML file
header('Content-Type: application/json');
echo json_encode([
    'success' => true,
    'message' => 'API test successful!',
    'path' => 'This file is accessible'
]);
?>