<?php
    // Fetch active announcements from database
    require_once 'db.php';
    
    $sql = "SELECT * FROM announcements 
            WHERE status = 'active' 
            AND publish_date <= CURDATE() 
            ORDER BY publish_date DESC, created_at DESC 
            LIMIT 6";
    
    $result = mysqli_query($conn, $sql);
    $announcements = [];
    if ($result) {
        $announcements = mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
    
    // Fetch recent sermons
    $sql = "SELECT * FROM sermons ORDER BY sermon_date DESC LIMIT 3";
    $result = mysqli_query($conn, $sql);
    $recent_sermons = [];
    if ($result) {
        $recent_sermons = mysqli_fetch_all($result, MYSQLI_ASSOC);
    }

    // Fetch active live stream - MOVED OUTSIDE THE SERMONS CONDITION
    $active_stream_query = "SELECT * FROM livestreams WHERE is_live=1 ORDER BY updated_at DESC LIMIT 1";
    $active_stream_result = mysqli_query($conn, $active_stream_query);
    $active_stream = mysqli_fetch_assoc($active_stream_result);
    
    mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Anglican Church of Epiphany</title>

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Inter:wght@300;400;600&display=swap" rel="stylesheet">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <!-- AOS for animations -->
  <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet">

  <style>
    :root{
      --gold: #caa32b;
      --light-bg: #f9f9f9;
      --light-text: #222;
      --dark-bg: #070707;
      --dark-text: #f5f5f5;
      --muted-light: #6c757d;
      --muted-dark: #d1d1d1;
      --accent: #4b2e1e;
      --card-radius: 14px;
    }

    /* Base */
    *{box-sizing:border-box}
    body{
      margin:0;
      font-family:"Inter",system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial;
      background:var(--light-bg);
      color:var(--light-text);
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
      transition:background .25s ease,color .25s ease;
    }
    body.dark-mode{
      background:var(--dark-bg);
      color:var(--dark-text);
    }

    /* Navbar */
    .navbar{
      background:var(--light-bg);
      border-bottom:1px solid rgba(0,0,0,0.06);
      transition:background .25s ease;
    }
    body.dark-mode .navbar{
      background:rgba(11,11,11,0.95);
      border-bottom:1px solid rgba(255,255,255,0.06);
    }
    .navbar-brand{ color:var(--gold) !important; font-weight:700; display:flex; gap:10px; align-items:center; }
    .navbar-brand img{ width:44px; height:44px; object-fit:cover; border-radius:8px; }
    .nav-link{ color:var(--light-text) !important; font-weight:600; }
    body.dark-mode .nav-link{ color:var(--dark-text) !important; }
    .nav-link:hover{ color:var(--gold) !important; }

    /* Toggle */
    .toggle-btn{ background:none; border:none; font-size:1.25rem; cursor:pointer; color:var(--light-text); }
    body.dark-mode .toggle-btn{ color:var(--dark-text); }

    /* Hero */
    .hero{
      min-height:78vh;
      display:flex;
      align-items:center;
      justify-content:center;
      background-size:cover;
      background-position:center;
      position:relative;
      color:#fff;
    }
    .hero::after{
      content:"";
      position:absolute; inset:0;
      background:linear-gradient(180deg,rgba(0,0,0,0.45),rgba(0,0,0,0.35));
      transition:background .25s ease;
    }
    body.dark-mode .hero::after{ background:linear-gradient(180deg,rgba(0,0,0,0.60),rgba(0,0,0,0.50)); }
    .hero .hero-card{ position:relative; z-index:2; backdrop-filter: blur(0px); }

    .section-title{
      font-family:"Playfair Display",serif;
      color:var(--gold);
      font-size:2rem;
      margin-bottom:1.25rem;
      text-align:center;
    }

    .text-muted{ color:var(--muted-light) !important; }
    body.dark-mode .text-muted{ color:var(--muted-dark) !important; }

    /* Services */
    .service{
      background:rgba(255,255,255,0.95);
      padding:22px;
      border-radius:var(--card-radius);
      transition:background .25s ease, border .25s ease, transform .2s ease, box-shadow .2s ease;
    }
    body.dark-mode .service{ background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.06); color:var(--dark-text); }
    .service:hover{ transform:translateY(-6px); box-shadow:0 10px 30px rgba(0,0,0,0.06); }

    /* Cards & Announcements */
    .card{ border-radius:var(--card-radius); transition:background .25s ease, border .25s ease, color .25s ease; }
    #announcements .card{ transition:transform .25s ease, box-shadow .25s ease; }
    #announcements .card:hover{ transform:translateY(-6px); box-shadow:0 14px 35px rgba(0,0,0,0.08); }
    body.dark-mode #announcements .card{ background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.06); color:var(--dark-text); }

    /* Override Bootstrap bg-light in dark mode so sections invert properly */
    body.dark-mode .bg-light { background-color: var(--dark-bg) !important; }

    /* Live & Sermons */
    .bg-primary.custom{ background:linear-gradient(135deg,#2b6cb0,#1d4ed8); }
    body.dark-mode .bg-primary.custom{ background:linear-gradient(135deg,#0b263f,#07203a); }

    /* Ensure text-light toggles sensibly in dark mode where needed */
    body.dark-mode .text-light { color: var(--dark-text) !important; }

    /* Workers carousel styling (one by one) */
    #workers .carousel-inner { display: flex; align-items: center; justify-content: center; }
    #workers .carousel-item { display: flex; justify-content: center; align-items: center; padding: 1.25rem 0; }
    #workers .card { overflow:hidden; border-radius:12px; transition:transform .25s ease, box-shadow .25s ease; max-width:420px; width:100%; }
    #workers .card:hover{ transform:translateY(-6px); box-shadow:0 18px 40px rgba(0,0,0,0.12); }
    #workers .card-img-top{ height:320px; object-fit:cover; display:block; }
    #workers .card-body h5{ color:var(--accent); font-weight:700; margin-bottom:.25rem; }
    #workers .fa-phone{ color:#a37b59; margin-right:.35rem; }

    /* Cards in dark mode */
    body.dark-mode .card, body.dark-mode .service {
      background: rgba(255,255,255,0.03);
      border: 1px solid rgba(255,255,255,0.06);
      color: var(--dark-text);
    }

    /* Button styling */
  .btns {
    text-decoration: none;
    position: relative;
    padding: 15px 40px;
    border: none;
    outline: none;
    color: #fff;
    border-radius: 12px;
    cursor: pointer;
    font-size: 1rem;
    z-index: 0;
    transition: color 0.3s ease-in-out;
  }
  
  /* Pulsating Glow Effect */
  .btns::before {
    content: "";
    position: absolute;
    top: -2px;
    left: -2px;
    width: calc(100% + 4px);
    height: calc(100% + 4px);
    background: linear-gradient(
      45deg,
      #ff0000,
      #ff7300,
      #fffb00,
      #48ff00,
      #00ffd5,
      #002bff,
      #ff00c8,
      #ff0000
    );
    background-size: 400%;
    border-radius: 14px;
    filter: blur(8px);
    z-index: -1;
    animation: pulsate 6s infinite;
    opacity: 0.7;
    transition: opacity 0.3s ease-in-out;
  }
  
  @keyframes pulsate {
    0%, 100% {
      background-position: 0 0;
      opacity: 0.7;
    }
    50% {
      background-position: 100% 0;
      opacity: 1;
    }
  }
  
  /* Hover Effect */
  .btns:hover::before {
    opacity: 1;
  }
  
  .btns:hover {
    color: #000;
    background-color: #0ef;
  }
  
  /* Active (Clicked) State */
  .btns:active {
    transform: scale(0.95);
    box-shadow: 0 0 20px #0ef;
  }
  

    /* Buttons adjustment in dark mode */
    body.dark-mode .btn-light { background-color: #222 !important; color: var(--dark-text) !important; border: 1px solid rgba(255,255,255,0.06); }
    body.dark-mode .btn-primary { background-color: #164a7a !important; border-color: #164a7a !important; color: #fff !important; }

    /* Prayer form */
    #prayer-request .card{ border-radius:12px; }
    #prayer-request .btn-primary{ background:var(--accent); border:none; }
    #prayer-request .btn-primary:hover{ background:#5c3c28; }

    /* Contact */
    #contact .form-control{ border-radius:8px; background:white; color:inherit; }
    body.dark-mode #contact .form-control{ background: rgba(255,255,255,0.03); color:var(--dark-text); border:1px solid rgba(255,255,255,0.06); }

    /* Footer */
    footer{ padding:28px 0; background:var(--light-bg); transition:background .25s ease; }
    body.dark-mode footer{ background:var(--dark-bg); }
    footer p{ margin:0; color:var(--muted-light); }
    body.dark-mode footer p{ color:var(--muted-dark); }

    @media (max-width:767px){
      .hero{ min-height:55vh; padding:3rem 1rem; }
      #workers .card-img-top{ height:230px; }
    }
  </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg sticky-top shadow-sm" data-aos="fade-down">
  <div class="container">
    <a class="navbar-brand" href="#home">
      <!-- Logo image (replace ./logo.png with your logo file) -->
      <img src="./church.jpg" alt="AC Logo">
      <span class="ms-2">Anglican Church of Epiphany</span>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu" aria-controls="navMenu" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-lg-center">
        <li class="nav-item"><a class="nav-link" href="#home">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
        <li class="nav-item"><a class="nav-link" href="#services">Services</a></li>
        <li class="nav-item"><a class="nav-link" href="#announcements">Announcements</a></li>
        <li class="nav-item"><a class="nav-link" href="#sermons">Sermons</a></li>
        <li class="nav-item"><a class="nav-link" href="#workers">Team</a></li>
        <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
      </ul>

      <button class="toggle-btn ms-3" onclick="toggleMode()" aria-label="Toggle dark mode" aria-pressed="false">🌙</button>
    </div>
  </div>
</nav>

<!-- HERO -->
<section id="home" class="hero" style="background-image:url('./church.jpg');" data-aos="fade-up">
  <div class="container hero-card text-center text-white">
    <h1 class="display-5 fw-bold">Welcome to the Anglican Church of Epiphany</h1>
    <p class="lead mb-4">A place of worship, community, and spiritual growth.</p>
    <div class="d-flex justify-content-center gap-3">
      <a href="#live-stream" class="btn btn-warning btn-lg fw-semibold">Join Live</a>
      <a href="#about" class="btn btn-outline-light btn-lg">Learn More</a>
    </div>
  </div>
</section>

<!-- ABOUT -->
<section id="about" class="py-5" data-aos="fade-up">
  <div class="container">
    <h2 class="section-title">About Us</h2>
    <div class="row align-items-center g-4">
      <div class="col-lg-6">
        <p class="text-muted fs-6">The Anglican Church of Epiphany is a welcoming community dedicated to spreading the Gospel of Christ through worship, outreach, and service. We are committed to nurturing faith and fostering fellowship among our members and neighbors.</p>
        <ul class="text-muted">
          <li>Weekly worship services and Bible studies</li>
          <li>Community outreach programs</li>
          <li>Youth and children ministries</li>
          <li>Marriage counseling and family support</li>
        </ul>
      </div>
      <div class="col-lg-6" data-aos="fade-left">
        <img src="./church.jpg" alt="Church building" class="img-fluid rounded shadow-sm" style="border-radius:12px;">
      </div>
    </div>
  </div>
</section>

<!-- SERVICES -->
<section id="services" class="py-5" data-aos="fade-up">
  <div class="container">
    <h2 class="section-title">Our Services</h2>
    <div class="row g-4">
      <div class="col-md-6 col-lg-3" data-aos="zoom-in"><div class="service h-100 text-center"><h5 class="fw-bold">Sunday Worship</h5><p class="text-muted small">Join us every Sunday for uplifting worship and teaching.</p></div></div>
      <div class="col-md-6 col-lg-3" data-aos="zoom-in" data-aos-delay="100"><div class="service h-100 text-center"><h5 class="fw-bold">Bible Study</h5><p class="text-muted small">Grow in your understanding of God’s word with weekly study sessions.</p></div></div>
      <div class="col-md-6 col-lg-3" data-aos="zoom-in" data-aos-delay="200"><div class="service h-100 text-center"><h5 class="fw-bold">Community Outreach</h5><p class="text-muted small">Serving our neighbors through love, care, and support.</p></div></div>
      <div class="col-md-6 col-lg-3" data-aos="zoom-in" data-aos-delay="300"><div class="service h-100 text-center"><h5 class="fw-bold">Youth Ministry</h5><p class="text-muted small">Empowering the next generation with spiritual guidance.</p></div></div>
    </div>
  </div>
</section>

<!-- ANNOUNCEMENTS -->
<section id="announcements" class="py-5 bg-light" data-aos="fade-up">
  <div class="container">
    <h2 class="section-title">Church Announcements</h2>


    <div class="row g-4">
      <?php if (empty($announcements)): ?>
        <!-- Show default message when no announcements -->
        <div class="col-12">
          <div class="card shadow-sm text-center py-5">
            <div class="card-body">
              <i class="fas fa-bullhorn fa-3x text-muted mb-3"></i>
              <h5 class="text-muted">No Announcements Yet</h5>
              <p class="text-muted">Check back later for updates from the church.</p>
            </div>
          </div>
        </div>
      <?php else: ?>
        <?php foreach ($announcements as $announcement): ?>
          <div class="col-md-6 col-lg-4">
            <div class="card shadow-sm h-100 announcement-card">
              <div class="card-body">
                <!-- Category Badge with dynamic colors -->
                <?php
                $badge_class = 'bg-secondary'; // default
                switch($announcement['category']) {
                  case 'Urgent':
                    $badge_class = 'bg-danger';
                    break;
                  case 'Event':
                    $badge_class = 'bg-primary';
                    break;
                  case 'Update':
                    $badge_class = 'bg-info';
                    break;
                  case 'Notice':
                    $badge_class = 'bg-warning text-dark';
                    break;
                  case 'General':
                    $badge_class = 'bg-success';
                    break;
                }
                ?>
                <span class="badge <?= $badge_class ?> mb-2"><?= htmlspecialchars($announcement['category']) ?></span>
                
                <h5 class="card-title"><?= htmlspecialchars($announcement['title']) ?></h5>
                <p class="card-text text-muted small">
                  <?= nl2br(htmlspecialchars($announcement['content'])) ?>
                </p>
                <p class="small text-muted">
                  <i class="fas fa-calendar-alt me-2"></i>
                  <?= date('F j, Y', strtotime($announcement['publish_date'])) ?>
                  <?php if ($announcement['publish_date'] != $announcement['created_at']): ?>
                    <br><i class="fas fa-clock me-2"></i>Posted: <?= date('M j, Y', strtotime($announcement['created_at'])) ?>
                  <?php endif; ?>
                </p>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
<br>
    <?php if (!empty($announcements) && count($announcements) >= 3): ?>
    <?php endif; ?>
  </div>
</section>
<div class="text-center mt-4">
        <a href="announcements.php" class="btns btn btn-primary px-4 py-2">
          <i class="fas fa-list me-2"></i>View All Announcements
        </a>
      </div>
      <br>
<!-- LIVE STREAM -->
<section id="live-stream" class="py-5 bg-primary text-light custom" data-aos="fade-up">
  <div class="container">
    <h2 class="section-title text-center text-light">Live Streaming</h2>
    
    <?php 
    // Debug: Check if active_stream exists and is live
    $is_live = ($active_stream && $active_stream['is_live'] == 1);
    ?>
    
    <?php if ($is_live): ?>
    <!-- Active Live Stream -->
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="card border-0 shadow-lg">
          <div class="card-header bg-danger text-white d-flex justify-content-between align-items-center">
            <div>
              <i class="fas fa-circle me-2 live-indicator"></i>
              <strong>LIVE NOW</strong>
            </div>
            <span class="badge bg-light text-danger">
              <?= date('g:i A', strtotime($active_stream['updated_at'])) ?>
            </span>
          </div>
          <div class="card-body p-0">
            <div class="ratio ratio-16x9">
              <?php if (strpos($active_stream['stream_url'], 'youtube.com') !== false || strpos($active_stream['stream_url'], 'youtu.be') !== false): ?>
                <!-- YouTube Embed -->
                <iframe 
                  src="<?= htmlspecialchars($active_stream['stream_url']) ?>" 
                  frameborder="0" 
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                  allowfullscreen>
                </iframe>
              <?php elseif (strpos($active_stream['stream_url'], 'facebook.com') !== false): ?>
                <!-- Facebook Embed -->
                <iframe 
                  src="<?= htmlspecialchars($active_stream['stream_url']) ?>" 
                  style="border: none; overflow: hidden;" 
                  scrolling="no" 
                  frameborder="0" 
                  allowTransparency="true" 
                  allow="encrypted-media" 
                  allowFullScreen="true">
                </iframe>
              <?php else: ?>
                <!-- Generic Video Player for RTMP/other streams -->
                <div class="bg-dark d-flex align-items-center justify-content-center text-white">
                  <div class="text-center">
                    <i class="fas fa-broadcast-tower fa-3x mb-3 text-danger"></i>
                    <h4>Live Stream in Progress</h4>
                    <p><?= htmlspecialchars($active_stream['title']) ?></p>
                    <a href="<?= htmlspecialchars($active_stream['stream_url']) ?>" 
                       target="_blank" 
                       class="btn btn-danger btn-lg mt-2">
                      <i class="fas fa-play me-2"></i>Watch Live Stream
                    </a>
                  </div>
                </div>
              <?php endif; ?>
            </div>
          </div>
          <div class="card-footer bg-light">
            <h5 class="text-dark mb-2"><?= htmlspecialchars($active_stream['title']) ?></h5>
            <?php if ($active_stream['description']): ?>
              <p class="text-muted mb-0"><?= htmlspecialchars($active_stream['description']) ?></p>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <div class="text-center mt-4">
      <a href="<?= htmlspecialchars($active_stream['stream_url']) ?>" 
         target="_blank" 
         class="btn btn-light px-4 py-2">
        <i class="fas fa-external-link-alt me-2"></i>Open in New Tab
      </a>
    </div>

    <?php else: ?>
    <!-- No Active Live Stream -->
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="ratio ratio-16x9 rounded shadow-sm overflow-hidden bg-dark">
          <div class="d-flex align-items-center justify-content-center text-white">
            <div class="text-center">
              <i class="fas fa-broadcast-tower fa-4x mb-3 text-secondary"></i>
              <h3>No Live Stream Currently</h3>
              <p class="mb-4">Check back later for our next live service</p>
              
              <!-- Show upcoming streams if any -->
              <?php
              require_once 'db.php';
              $upcoming_streams_query = "SELECT * FROM livestreams WHERE (scheduled_time > NOW() OR scheduled_time IS NULL) AND is_live=0 ORDER BY scheduled_time ASC LIMIT 3";
              $upcoming_streams = mysqli_query($conn, $upcoming_streams_query);
              
              if ($upcoming_streams && mysqli_num_rows($upcoming_streams) > 0): 
              ?>
                <div class="mt-4">
                  <h5 class="text-warning mb-3">Upcoming Live Streams</h5>
                  <div class="row justify-content-center">
                    <?php while ($stream = mysqli_fetch_assoc($upcoming_streams)): ?>
                    <div class="col-md-6 mb-3">
                      <div class="card bg-dark border-warning">
                        <div class="card-body text-start">
                          <h6 class="card-title text-warning"><?= htmlspecialchars($stream['title']) ?></h6>
                          <?php if ($stream['description']): ?>
                            <p class="card-text small text-light"><?= htmlspecialchars($stream['description']) ?></p>
                          <?php endif; ?>
                          <div class="d-flex justify-content-between align-items-center">
                            <small class="text-light">
                              <i class="fas fa-clock me-1"></i>
                              <?= $stream['scheduled_time'] ? date('M j, Y g:i A', strtotime($stream['scheduled_time'])) : 'TBA' ?>
                            </small>
                            <span class="badge bg-warning">Upcoming</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <?php endwhile; ?>
                  </div>
                </div>
              <?php endif; 
              mysqli_close($conn);
              ?>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="text-center mt-4">
      <a href="https://web.facebook.com/share/v/1YmnoWk1vy/" target="_blank" class="btn btn-light px-4 py-2">
        <i class="fab fa-facebook me-2"></i>Visit Our Facebook Page
      </a>
    </div>
    <?php endif; ?>

    <div class="text-center mt-3">
      <p id="liveStatus" class="fw-bold text-light">
        <?php if ($is_live): ?>
          <i class="fas fa-circle text-danger me-2 live-indicator"></i>
          We're live now! Join us for <?= htmlspecialchars($active_stream['title']) ?>
        <?php else: ?>
          <i class="fas fa-circle text-secondary me-2"></i>
          If no video is showing, there is no live stream at the moment.
        <?php endif; ?>
      </p>
    </div>
  </div>
</section>

<style>
@keyframes pulse {
  0% { opacity: 1; }
  50% { opacity: 0.5; }
  100% { opacity: 1; }
}

.live-indicator {
  animation: pulse 1.5s infinite;
}
</style>

<script>
// Auto-refresh the page every 60 seconds to check for new live streams
setInterval(() => {
  console.log('Checking for live stream updates...');
  window.location.reload();
}, 60000);

// Add manual refresh button
document.addEventListener('DOMContentLoaded', function() {
  const statusElement = document.getElementById('liveStatus');
  if (statusElement) {
    const refreshBtn = document.createElement('button');
    refreshBtn.className = 'btn btn-outline-light btn-sm mt-2 ms-2';
    refreshBtn.innerHTML = '<i class="fas fa-sync-alt me-1"></i>Check for Live Stream';
    refreshBtn.onclick = function() {
      refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Checking...';
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    };
    statusElement.parentNode.appendChild(refreshBtn);
  }
});
</script>
<!-- SERMONS -->
<section id="sermons" class="py-5 bg-dark text-light" data-aos="fade-up">
  <div class="container">
    <h2 class="section-title text-center text-warning">Watch Our Sermons</h2>

    <?php if (empty($recent_sermons)): ?>
      <!-- Show default video when no sermons -->
      <div class="row justify-content-center mb-5">
        <div class="col-lg-8">
          <div class="ratio ratio-16x9 rounded shadow-sm overflow-hidden">
            <iframe id="mainVideo"
              src="https://www.facebook.com/plugins/video.php?height=314&href=https%3A%2F%2Fweb.facebook.com%2F100086051042420%2Fvideos%2F1748714003191654%2F&show_text=false&width=560&t=0"
              style="border:0;"
              allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"
              allowfullscreen>
            </iframe>
          </div>
        </div>
      </div>
    <?php else: ?>
      <!-- Show latest sermon as main video -->
      <div class="row justify-content-center mb-5">
        <div class="col-lg-8">
          <div class="ratio ratio-16x9 rounded shadow-sm overflow-hidden">
            <?php 
            $latest_sermon = $recent_sermons[0];
            if ($latest_sermon['video_url']): 
            ?>
              <iframe 
                src="<?= htmlspecialchars($latest_sermon['video_url']) ?>" 
                style="border:0;"
                allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"
                allowfullscreen>
              </iframe>
            <?php else: ?>
              <!-- Fallback to default video if no video URL -->
              <iframe
                src="https://www.facebook.com/plugins/video.php?height=314&href=https%3A%2F%2Fweb.facebook.com%2F100086051042420%2Fvideos%2F1748714003191654%2F&show_text=false&width=560&t=0"
                style="border:0;"
                allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"
                allowfullscreen>
              </iframe>
            <?php endif; ?>
          </div>
          <div class="mt-3 text-center">
            <h4 class="text-warning"><?= htmlspecialchars($latest_sermon['title']) ?></h4>
            <p class="text-light mb-1">
              <i class="fas fa-user me-2"></i>By <?= htmlspecialchars($latest_sermon['speaker']) ?>
            </p>
            <p class="text-light mb-0">
              <i class="fas fa-calendar me-2"></i><?= date('F j, Y', strtotime($latest_sermon['sermon_date'])) ?>
            </p>
            <?php if ($latest_sermon['description']): ?>
              <p class="text-light mt-2"><?= nl2br(htmlspecialchars($latest_sermon['description'])) ?></p>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Show additional sermons as thumbnails if available -->
      <?php if (count($recent_sermons) > 1): ?>
        <div class="row g-4 mb-5">
          <div class="col-12">
            <h4 class="text-center mb-4">More Recent Sermons</h4>
          </div>
          <?php for ($i = 1; $i < count($recent_sermons); $i++): ?>
            <?php $sermon = $recent_sermons[$i]; ?>
            <div class="col-md-6 col-lg-4">
              <div class="card bg-secondary text-light h-100 sermon-thumbnail">
                <div class="card-body">
                  <h5 class="card-title"><?= htmlspecialchars($sermon['title']) ?></h5>
                  <p class="card-text small">
                    <i class="fas fa-user me-2"></i><?= htmlspecialchars($sermon['speaker']) ?>
                  </p>
                  <p class="card-text small">
                    <i class="fas fa-calendar me-2"></i><?= date('M j, Y', strtotime($sermon['sermon_date'])) ?>
                  </p>
                  <?php if ($sermon['description']): ?>
                    <p class="card-text small"><?= nl2br(htmlspecialchars(substr($sermon['description'], 0, 100))) ?>...</p>
                  <?php endif; ?>
                </div>
                <div class="card-footer bg-dark">
                  <?php if ($sermon['video_url']): ?>
                    <a href="<?= htmlspecialchars($sermon['video_url']) ?>" 
                       target="_blank" 
                       class="btn btn-warning btn-sm w-100">
                      <i class="fas fa-play me-1"></i>Watch Now
                    </a>
                  <?php elseif ($sermon['audio_url']): ?>
                    <a href="<?= htmlspecialchars($sermon['audio_url']) ?>" 
                       target="_blank" 
                       class="btn btn-outline-light btn-sm w-100">
                      <i class="fas fa-headphones me-1"></i>Listen Now
                    </a>
                  <?php else: ?>
                    <button class="btn btn-outline-light btn-sm w-100" disabled>
                      <i class="fas fa-info-circle me-1"></i>No Media Available
                    </button>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          <?php endfor; ?>
        </div>
      <?php endif; ?>
    <?php endif; ?>

    <div class="text-center">
      <a href="sermons.php" class="btn btn-primary px-4 py-2">
        <i class="fas fa-video me-2"></i>View All Sermons
      </a>
    </div>
  </div>
</section>

<!-- TEAM SECTION -->
<section id="team" class="py-5 bg-light">
    <div class="container">
      <h2 class="section-title text-center mb-4">Meet Our Team</h2>
  
      <div id="teamCarousel" class="carousel slide" data-bs-ride="carousel">
        
        <!-- Indicators -->
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#teamCarousel" data-bs-slide-to="0" class="active"></button>
          <button type="button" data-bs-target="#teamCarousel" data-bs-slide-to="1"></button>
          <button type="button" data-bs-target="#teamCarousel" data-bs-slide-to="2"></button>
          <button type="button" data-bs-target="#teamCarousel" data-bs-slide-to="3"></button>
        </div>
  
        <!-- Carousel Inner -->
        <div class="carousel-inner">
  
          <!-- Team Member 1 -->
          <div class="carousel-item active text-center">
            <img src="./images/priest.jpg" class="d-block mx-auto rounded-circle shadow" 
                 alt="Team Member 1" style="width:300px; height:300px; object-fit:cover;">
            <div class="mt-4">
              <h5 class="fw-bold">Rev. Basil Ozoemena</h5>
              <p class="text-muted mb-1">Parish Priest</p>
              <p class="mb-0"><i class="fas fa-phone"></i> +234 801 234 5678</p>
            </div>
          </div>
  
          <!-- Team Member 2 -->
          <div class="carousel-item text-center">
            <img src="./images/priest wife.jpg" class="d-block mx-auto rounded-circle shadow" 
                 alt="Team Member 2" style="width:300px; height:300px; object-fit:cover;">
            <div class="mt-4">
              <h5 class="fw-bold">Mrs Udoka Basil</h5>
              <p class="text-muted mb-1">Priest Wife</p>
              <p class="mb-0"><i class="fas fa-phone"></i> +234 809 876 5432</p>
            </div>
          </div>
  
          <!-- Team Member 3 -->
          <div class="carousel-item text-center">
            <img src="./WhatsApp Image 2025-01-21 at 14.01.10_f0bcd58c.jpg" class="d-block mx-auto rounded-circle shadow" 
                 alt="Team Member 3" style="width:300px; height:300px; object-fit:cover;">
            <div class="mt-4">
              <h5 class="fw-bold">Mr Uchenna Chukwuka</h5>
              <p class="text-muted mb-1">Pastor's Warden</p>
              <p class="mb-0"><i class="fas fa-phone"></i> +234 803 222 1111</p>
            </div>
          </div>
  
          <!-- Team Member 4 -->
          <div class="carousel-item text-center">
            <img src="./team4.jpg" class="d-block mx-auto rounded-circle shadow" 
                 alt="Team Member 4" style="width:300px; height:300px; object-fit:cover;">
            <div class="mt-4">
              <h5 class="fw-bold">Barr.Tochukwu Nwachukwu.PHD.</h5>
              <p class="text-muted mb-1">Peoples's Warden</p>
              <p class="mb-0"><i class="fas fa-phone"></i> +234 802 999 8888</p>
            </div>
          </div>
  
        </div>
  
        <!-- Carousel Controls -->
        <button class="carousel-control-prev" type="button" data-bs-target="#teamCarousel" data-bs-slide="prev">
          <span class="carousel-control-prev-icon bg-dark rounded-circle"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#teamCarousel" data-bs-slide="next">
          <span class="carousel-control-next-icon bg-dark rounded-circle"></span>
        </button>
      </div>
    </div>
  </section>

  <div class="text-center">
     <!-- <button class="btns" a href="./thank-you.html">View More Images</button>  -->
     <a href="./gallery.php" class="btns">VISIT OUR GALLERY</a>
    </div>
  

<!-- PRAYER REQUEST (left as-is) -->
<!-- PRAYER REQUEST (updated for database integration) -->
<section id="prayer-request" class="py-5" data-aos="fade-up">
  <div class="container">
    <h2 class="section-title">Submit a Prayer Request</h2>
    <p class="text-muted text-center mb-4">Share your burdens and let us pray for you. Your request will be kept confidential.</p>

    <div class="row justify-content-center">
      <div class="col-md-8">
        <div class="card shadow-sm p-4">
          <form id="prayerForm" method="POST" action="submit_prayer.php" novalidate>
            <div class="mb-3">
              <label for="name" class="form-label fw-semibold">Full Name</label>
              <input type="text" id="name" name="name" class="form-control" placeholder="Enter your full name" required>
            </div>

            <div class="mb-3">
              <label for="email" class="form-label fw-semibold">Email Address</label>
              <input type="email" id="email" name="email" class="form-control" placeholder="Enter your email address" required>
            </div>

            <div class="mb-3">
              <label for="phone" class="form-label fw-semibold">Phone Number (Optional)</label>
              <input type="tel" id="phone" name="phone" class="form-control" placeholder="+234 800 000 0000">
            </div>

            <div class="mb-3">
              <label for="category" class="form-label fw-semibold">Prayer Category</label>
              <select id="category" name="category" class="form-select" required>
                <option value="" disabled selected>Select a category</option>
                <option>Healing</option>
                <option>Financial Breakthrough</option>
                <option>Family</option>
                <option>Faith</option>
                <option>Other</option>
              </select>
            </div>

            <div class="mb-3">
              <label for="message" class="form-label fw-semibold">Prayer Request</label>
              <textarea id="message" name="message" class="form-control" rows="5" placeholder="Write your prayer request here..." required></textarea>
            </div>

            <div class="d-grid">
              <button type="submit" class="btn btn-primary btn-lg fw-semibold">Submit Prayer Request</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<div class="text-center">
  <a href="./pay.php" class="btns">KWUO UGWO CLASS GI !!!</a><!--it a payment and donation button-->
 </div>
 <br><br>

<!-- CONTACT -->
<form id="contactForm" class="card p-4 shadow-sm" action="contact.php" method="POST">
<section id="contact" class="py-5 bg-light" data-aos="fade-up">
  <div class="container">
    <h2 class="section-title">Contact Us</h2>
    <div class="row g-4">
      <div class="col-lg-6">
        <form id="contactForm" class="card p-4 shadow-sm">
          <div class="mb-3">
            <input class="form-control" type="text" placeholder="Your Name" required>
          </div>
          <div class="mb-3">
            <input class="form-control" type="email" placeholder="Your Email" required>
          </div>
          <div class="mb-3">
            <textarea class="form-control" placeholder="Message" rows="4" required></textarea>
          </div>
          <div class="d-grid">
            <button class="btn btn-warning fw-semibold" type="submit">Send Message</button>
          </div>
        </form>
      </div>
      

      <div class="col-lg-6">
        <div class="h-100 p-4">
          <h5>Visit Us</h5>
          <p class="text-muted mb-1">Lagos, Nigeria</p>
          <p class="text-muted mb-1">Email: info@epiphanychurch.org</p>
          <p class="text-muted">Phone: +234 801 234 5678</p>

          <hr>

          <h6 class="mb-2">Service Times</h6>
          <p class="text-muted small mb-1">Sunday Worship — 9:00 AM</p>
          <p class="text-muted small mb-1">Bible Study — Wednesdays 6:00 PM</p>
        </div>
      </div>
    </div>
  </div>
</section>



  

<!-- FOOTER -->
<footer>
  <div class="container text-center">
    <p class="mb-0">&copy; <span id="year"></span> Anglican Church of Epiphany. All rights reserved.</p>
  </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- AOS JS -->
<script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>

<script>
  // Initialize AOS animations
  AOS.init({ duration: 800, once: true });

  // set current year
  document.getElementById('year').textContent = new Date().getFullYear();

  // Initialize theme from localStorage
  (function () {
    try {
      const saved = localStorage.getItem('ace-theme');
      const btn = document.querySelector('.toggle-btn');
      if (saved === 'dark') {
        document.body.classList.add('dark-mode');
        if (btn) { btn.textContent = '☀️'; btn.setAttribute('aria-pressed','true'); }
      } else {
        if (btn) { btn.textContent = '🌙'; btn.setAttribute('aria-pressed','false'); }
      }
    } catch (e) {
      console.warn('Theme load failed', e);
    }
  })();

  // Toggle dark mode (persisted)
  function toggleMode(){
    const btn = document.querySelector('.toggle-btn');
    const isDark = document.body.classList.toggle('dark-mode');
    if (btn) { btn.textContent = isDark ? '☀️' : '🌙'; btn.setAttribute('aria-pressed', isDark ? 'true' : 'false'); }
    try { localStorage.setItem('ace-theme', isDark ? 'dark' : 'light'); } catch(e) {}
  }

  // Prayer form simple front-end validation
  document.getElementById('prayerForm')?.addEventListener('submit', function(e){
    const n = document.getElementById('name').value.trim();
    const em = document.getElementById('email').value.trim();
    const cat = document.getElementById('category').value;
    const msg = document.getElementById('message').value.trim();
    if (!n || !em || !cat || !msg) {
      alert('Please complete all required fields before submitting the prayer request.');
      e.preventDefault();
    }
  });

  // Simple contact form client-side prevent default (you can wire up backend)
  document.getElementById('contactForm')?.addEventListener('submit', function(e){
    e.preventDefault();
    alert('Thank you — your message has been received. (Hook up backend to send actual messages.)');
    this.reset();
  });


// Add this to your existing JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Check for prayer submission status in URL
    const urlParams = new URLSearchParams(window.location.search);
    const prayerStatus = urlParams.get('prayer_status');
    
    if (prayerStatus === 'success') {
        alert('Thank you! Your prayer request has been submitted successfully.');
        // Remove the parameter from URL
        window.history.replaceState({}, document.title, window.location.pathname);
    } else if (prayerStatus === 'error') {
        alert('Sorry, there was an error submitting your prayer request. Please try again.');
        window.history.replaceState({}, document.title, window.location.pathname);
    }
});
  // If you'd like to detect live video availability you can add AJAX checks (omitted for now)
</script>
</body>
</html>
